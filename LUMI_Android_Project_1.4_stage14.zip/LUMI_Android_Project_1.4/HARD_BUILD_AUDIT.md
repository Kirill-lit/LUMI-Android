# LUMI 1.2 — hard build audit

## Static checks executed
- `reverse_engineering/preflight_check.py`: all 20 static checks passed.
- Android manifest XML parses.
- GitHub Actions workflow YAML parses.
- Checked that the real catalogue repository is wired into the UI.
- Checked that stream metadata resolution is wired into ExoPlayer launch.
- Checked that source-page links are restricted to `https://archive.org/`.
- Checked that Coil is declared for poster loading.
- Checked that test source files exist.

## Real catalogue/player implementation
- Uses Internet Archive Advanced Search for `mediatype:movies` with a Creative Commons license URL.
- Loads title, year, description, thumbnail, source page, and readable license label.
- Fetches item metadata on selection and chooses a supported non-private media file (MP4/HLS/DASH/WebM/OGV).
- Passes the resulting URL and MIME type into the existing Media3 ExoPlayer screen.
- Keeps position history and playback resume logic.

## Not yet verified
The actual Gradle/Kotlin compilation, unit-test execution, APK assembly, installation, and playback on a physical device have NOT been run. The execution environment has Java 21 but no Gradle, Gradle wrapper, Android SDK, Kotlin compiler, `adb`, or outbound network. Therefore this is a hard static audit, not a successful Android build.

## Build route
The GitHub Actions workflow provisions JDK 17, Android SDK 35, and Gradle 8.9; it runs `clean testDebugUnitTest assembleDebug`, uploads test/build reports even on failure, and uploads the debug APK only if the build succeeds. A green workflow is required before device testing.
