package app.lumi.catalog

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class ZonaRequestUrlBuilderTest {
    @Test
    fun encodesJsonAsSingleParamsValue() {
        val url = ZonaRequestUrlBuilder.buildParamsUrl(
            "https://apir0.mzona.net",
            "/getEpisodes",
            """{"entityId":42}"""
        )
        assertEquals(
            "https://apir0.mzona.net/getEpisodes?params=%7B%22entityId%22%3A42%7D",
            url
        )
    }

    @Test
    fun refusesVideoSourcesUntilTransformIsRecovered() {
        assertThrows(IllegalArgumentException::class.java) {
            ZonaRequestUrlBuilder.buildParamsUrl(
                "https://apir0.mzona.net",
                "/getVideoSources",
                """{"kinopoiskId":42}"""
            )
        }
    }

    @Test
    fun refusesUnlistedHost() {
        assertThrows(IllegalArgumentException::class.java) {
            ZonaRequestUrlBuilder.buildParamsUrl(
                "https://example.com",
                "/getEpisodes",
                """{"entityId":42}"""
            )
        }
    }
}
