package app.lumi.catalog

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InternetArchiveCatalogRepositoryTest {
    @Test
    fun onlyCreativeCommonsLicensesAreAccepted() {
        assertTrue(InternetArchiveCatalogRepository.isCreativeCommonsLicense("https://creativecommons.org/licenses/by/4.0/"))
        assertTrue(InternetArchiveCatalogRepository.isCreativeCommonsLicense("http://creativecommons.org/publicdomain/mark/1.0/"))
        assertFalse(InternetArchiveCatalogRepository.isCreativeCommonsLicense(""))
        assertFalse(InternetArchiveCatalogRepository.isCreativeCommonsLicense("https://example.com/license"))
    }

    @Test
    fun identifiersCannotContainPathOrQueryCharacters() {
        assertTrue(InternetArchiveCatalogRepository.isValidIdentifier("sample_film-1930"))
        assertFalse(InternetArchiveCatalogRepository.isValidIdentifier("../other"))
        assertFalse(InternetArchiveCatalogRepository.isValidIdentifier("id?query=1"))
    }

    @Test
    fun licenseLabelsAreReadable() {
        assertEquals("CC BY 4.0", InternetArchiveCatalogRepository.licenseLabel("https://creativecommons.org/licenses/by/4.0/"))
        assertEquals("CC BY-SA 3.0", InternetArchiveCatalogRepository.licenseLabel("https://creativecommons.org/licenses/by-sa/3.0/"))
        assertEquals("Public Domain Mark 1.0", InternetArchiveCatalogRepository.licenseLabel("https://creativecommons.org/publicdomain/mark/1.0/"))
    }

    @Test
    fun onlyKnownMediaExtensionsAreSelected() {
        assertEquals("video/mp4", InternetArchiveCatalogRepository.mediaMimeType("film.mp4"))
        assertEquals("application/x-mpegURL", InternetArchiveCatalogRepository.mediaMimeType("stream.m3u8"))
        assertEquals("application/dash+xml", InternetArchiveCatalogRepository.mediaMimeType("stream.mpd"))
        assertEquals(null, InternetArchiveCatalogRepository.mediaMimeType("metadata.xml"))
    }
}
