package app.lumi.catalog

/** UI-facing catalogue model. It intentionally does not expose Zona's internal DTOs. */
data class LumiTitle(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val year: String = "",
    val posterUrl: String? = null,
    val kind: TitleKind = TitleKind.MOVIE,
    val description: String = "",
    val stream: LumiStreamInfo? = null,
    val seriesId: String? = null,
    val sourceUrl: String? = null,
    val licenseUrl: String? = null,
)

enum class TitleKind { MOVIE, SERIES, EPISODE }

/** Playback fields reflected in the recovered Zona StreamInfo model. */
data class LumiStreamInfo(
    val url: String,
    val language: String? = null,
    val translation: String? = null,
    val quality: String? = null,
    val userAgent: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val mimeType: String? = null,
    val subtitles: List<LumiSubtitle> = emptyList(),
) {
    fun isHttpUrl(): Boolean = url.startsWith("https://", ignoreCase = true) ||
        url.startsWith("http://", ignoreCase = true)
}

data class LumiSubtitle(
    val name: String,
    val language: String? = null,
    val url: String,
    val mimeType: String? = null,
)

data class PlaybackHistoryItem(
    val contentId: String,
    val title: String,
    val seriesId: String? = null,
    val updatedAtMs: Long = System.currentTimeMillis(),
)
