package app.lumi.catalog

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Low-level client for endpoints whose request shape is observed as
 * ?params=<URL-encoded JSON>. This does not implement authentication, host
 * failover, or the special /getVideoSources transformation.
 *
 * Keep this opt-in until a real response and HTTP verb have been verified.
 */
class ZonaApiClient(
    private val baseUrl: String,
    private val connectTimeoutMs: Int = 8_000,
    private val readTimeoutMs: Int = 12_000,
    private val maxResponseBytes: Int = 4 * 1024 * 1024,
) {
    suspend fun requestParamsJson(path: String, serializedParamsJson: String): String =
        withContext(Dispatchers.IO) {
            val url = ZonaRequestUrlBuilder.buildParamsUrl(baseUrl, path, serializedParamsJson)
            executeGet(url)
        }

    suspend fun getEpisodes(entityId: Long): String {
        require(entityId > 0L) { "entityId must be positive" }
        val json = ZonaWireJson.json.encodeToString(
            ZonaGetEpisodesParams.serializer(),
            ZonaGetEpisodesParams(entityId = entityId)
        )
        return requestParamsJson("/getEpisodes", json)
    }

    private fun executeGet(urlString: String): String {
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(urlString).openConnection() as? HttpURLConnection)
                ?: throw IOException("Unsupported connection type")
            connection.requestMethod = "GET"
            connection.connectTimeout = connectTimeoutMs
            connection.readTimeout = readTimeoutMs
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("User-Agent", "LUMI/1.1 Android")
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.use { input ->
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > maxResponseBytes) throw IOException("Response exceeds size limit")
                    out.write(buffer, 0, count)
                }
                out.toString(StandardCharsets.UTF_8.name())
            }.orEmpty()

            if (status !in 200..299) {
                // Keep the diagnostic bounded; do not log tokens or full response bodies.
                throw ZonaApiException(status, body.take(1000))
            }
            return body
        } finally {
            connection?.disconnect()
        }
    }
}

class ZonaApiException(
    val httpStatus: Int,
    diagnostic: String,
) : IOException("Zona API returned HTTP $httpStatus${diagnostic.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ""}")
