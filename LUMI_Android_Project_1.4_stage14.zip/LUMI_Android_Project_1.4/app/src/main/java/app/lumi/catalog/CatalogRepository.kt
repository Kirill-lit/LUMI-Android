package app.lumi.catalog

/** Repository boundary so screens can be switched from demo data to a verified API later. */
interface CatalogRepository {
    suspend fun featured(): List<LumiTitle>
    suspend fun search(query: String): List<LumiTitle>
    suspend fun details(id: String): LumiTitle?
    suspend fun streams(id: String, episodeId: String? = null): List<LumiStreamInfo>
}

/** Safe offline catalogue used until Zona's real request/response contract is recovered. */
class DemoCatalogRepository : CatalogRepository {
    private val items = listOf(
        LumiTitle(
            id = "demo-film-001",
            title = "Тестовый фильм",
            subtitle = "Демонстрационный источник",
            year = "",
            kind = TitleKind.MOVIE,
            description = "Проверка плеера и продолжения просмотра.",
            stream = LumiStreamInfo(
                url = "https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4",
                mimeType = "video/mp4",
            ),
        ),
        LumiTitle(
            id = "demo-series-001-episode-001",
            title = "Тестовый сериал — серия 1",
            subtitle = "Демо-серия",
            kind = TitleKind.EPISODE,
            description = "Проверка запоминания языка для сериала.",
            seriesId = "demo-series-001",
            stream = LumiStreamInfo(
                url = "https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4",
                language = "ru",
                translation = "Русская",
                mimeType = "video/mp4",
            ),
        ),
    )

    val demoItems: List<LumiTitle> = items

    override suspend fun featured(): List<LumiTitle> = items

    override suspend fun search(query: String): List<LumiTitle> =
        if (query.isBlank()) items else items.filter {
            it.title.contains(query, ignoreCase = true) || it.description.contains(query, ignoreCase = true)
        }

    override suspend fun details(id: String): LumiTitle? = items.firstOrNull { it.id == id }

    override suspend fun streams(id: String, episodeId: String?): List<LumiStreamInfo> =
        items.firstOrNull { it.id == id || it.seriesId == id }?.stream?.let(::listOf) ?: emptyList()
}
