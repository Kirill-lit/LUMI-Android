package app.lumi

import android.content.Context
import app.lumi.catalog.PlaybackHistoryItem
import org.json.JSONArray
import org.json.JSONObject

/** Persistent playback position, per-series audio preference, and a compact local history. */
class PlaybackStore(context: Context) {
    private val prefs = context.getSharedPreferences("lumi_playback_v1", Context.MODE_PRIVATE)

    fun savePosition(contentId: String, positionMs: Long) {
        if (contentId.isBlank()) return
        prefs.edit().putLong("position:$contentId", positionMs.coerceAtLeast(0L)).apply()
    }

    fun position(contentId: String): Long =
        if (contentId.isBlank()) 0L else prefs.getLong("position:$contentId", 0L)

    fun saveAudioLanguage(seriesId: String, languageTag: String) {
        if (seriesId.isBlank() || languageTag.isBlank()) return
        prefs.edit().putString("audio:$seriesId", languageTag).apply()
    }

    fun audioLanguage(seriesId: String, fallback: String = "ru"): String =
        if (seriesId.isBlank()) fallback else prefs.getString("audio:$seriesId", fallback) ?: fallback


    fun isFavorite(contentId: String): Boolean =
        contentId.isNotBlank() && favorites().contains(contentId)

    fun toggleFavorite(contentId: String): Boolean {
        if (contentId.isBlank()) return false
        val values = favorites().toMutableSet()
        val nowFavorite = if (values.contains(contentId)) {
            values.remove(contentId)
            false
        } else {
            values.add(contentId)
            true
        }
        prefs.edit().putString("favorites", JSONArray(values.toList()).toString()).apply()
        return nowFavorite
    }

    fun favoriteIds(): Set<String> = favorites()

    private fun favorites(): Set<String> {
        val raw = prefs.getString("favorites", "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { array.optString(it).takeIf(String::isNotBlank) }.toSet()
        }.getOrDefault(emptySet())
    }

    fun clearPosition(contentId: String) {
        if (contentId.isNotBlank()) prefs.edit().remove("position:$contentId").apply()
    }

    fun saveHistory(contentId: String, title: String, seriesId: String?) {
        if (contentId.isBlank()) return
        val current = recentHistory().filterNot { it.contentId == contentId }.toMutableList()
        current.add(0, PlaybackHistoryItem(contentId, title, seriesId))
        val json = JSONArray()
        current.take(20).forEach { item ->
            json.put(JSONObject().apply {
                put("id", item.contentId)
                put("title", item.title)
                put("seriesId", item.seriesId ?: JSONObject.NULL)
                put("updatedAtMs", item.updatedAtMs)
            })
        }
        prefs.edit().putString("history", json.toString()).apply()
    }

    fun recentHistory(): List<PlaybackHistoryItem> {
        val raw = prefs.getString("history", "[]") ?: "[]"
        return runCatching {
            val json = JSONArray(raw)
            (0 until json.length()).mapNotNull { index ->
                val item = json.optJSONObject(index) ?: return@mapNotNull null
                val id = item.optString("id").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                PlaybackHistoryItem(
                    contentId = id,
                    title = item.optString("title", id),
                    seriesId = item.optString("seriesId").takeIf { it.isNotBlank() && it != "null" },
                    updatedAtMs = item.optLong("updatedAtMs"),
                )
            }
        }.getOrDefault(emptyList())
    }
}
