package app.lumi.catalog

/**
 * Boundary DTOs based on the fields observed in the provided APK's DEX metadata.
 * They are not claimed to be wire-compatible with Zona until the serializers/API contract are verified.
 */
data class ZonaStreamInfoDto(
    val url: String?,
    val language: String? = null,
    val translation: String? = null,
    val quality: String? = null,
    val userAgent: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val codec: String? = null,
    val subtitles: List<ZonaSubtitleDto> = emptyList(),
)

data class ZonaSubtitleDto(
    val codec: String? = null,
    val language: String? = null,
    val name: String? = null,
    val url: String? = null,
)

fun ZonaStreamInfoDto.toLumiStreamInfo(): LumiStreamInfo? {
    val validUrl = url?.takeIf { it.startsWith("https://") || it.startsWith("http://") } ?: return null
    return LumiStreamInfo(
        url = validUrl,
        language = language,
        translation = translation,
        quality = quality,
        userAgent = userAgent,
        headers = headers,
        mimeType = codec.toMediaMimeType(validUrl),
        subtitles = subtitles.mapNotNull { subtitle ->
            val subtitleUrl = subtitle.url?.takeIf { it.startsWith("https://") || it.startsWith("http://") }
                ?: return@mapNotNull null
            LumiSubtitle(
                name = subtitle.name ?: subtitle.language ?: "Субтитры",
                language = subtitle.language,
                url = subtitleUrl,
                mimeType = subtitle.codec.toSubtitleMimeType(),
            )
        },
    )
}

private fun String?.toMediaMimeType(url: String): String? = when {
    url.substringBefore('?').endsWith(".m3u8", ignoreCase = true) -> "application/x-mpegURL"
    url.substringBefore('?').endsWith(".mpd", ignoreCase = true) -> "application/dash+xml"
    url.substringBefore('?').endsWith(".mp4", ignoreCase = true) -> "video/mp4"
    this.equals("hls", ignoreCase = true) -> "application/x-mpegURL"
    this.equals("dash", ignoreCase = true) -> "application/dash+xml"
    else -> null
}

private fun String?.toSubtitleMimeType(): String? = when (this?.lowercase()) {
    "srt", "subrip" -> "application/x-subrip"
    "vtt", "webvtt" -> "text/vtt"
    else -> null
}
