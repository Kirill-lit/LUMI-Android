package app.lumi.catalog

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Wire DTOs reconstructed from Kotlin serialization metadata in zona5.apk.
 *
 * These describe observed model keys, not a complete API contract. Request
 * routes, authentication and response wrappers still require further recovery.
 */
@Serializable
data class ZonaWireEpisode(
    val title: String? = null,
    @SerialName("episode_key") val episodeKey: String? = null,
    @SerialName("mobi_link_id") val mobiLinkId: Long = 0L,
    val season: Int = 0,
    val episode: Int = 0,
    @SerialName("release_date") val releaseDate: String? = null,
    val isWatched: Boolean = false,
    val isEnable: Boolean = true,
)

@Serializable
data class ZonaWireVideoSource(
    val id: String? = null,
    @SerialName("episode_key") val episodeKey: String? = null,
    @SerialName("download_link_key") val downloadLinkKey: String? = null,
    @SerialName("kinopoisk_id") val kinopoiskId: Long = 0L,
    @SerialName("video_source_type_id") val videoSourceTypeId: Int = 0,
    @SerialName("video_content_type_id") val videoContentTypeId: Int = 0,
    val info: String? = null,
)

@Serializable
data class ZonaWireStreamInfo(
    val url: String? = null,
    val translation: String? = null,
    val language: String? = null,
    val quality: String? = null,
    val subtitleList: List<ZonaWireSubtitle> = emptyList(),
    val userAgent: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val unavailableQuality: Boolean = false,
    val isTrailer: Boolean = false,
    val videoSourceTypeId: Int = 0,
    val videoContentTypeId: Int = 0,
    val codec: String? = null,
)

@Serializable
data class ZonaWireSubtitle(
    val name: String? = null,
    val url: String? = null,
    val language: String? = null,
    val codec: String? = null,
)

@Serializable
data class ZonaWireVideoSourcesResponse(
    val total: Long = 0L,
    val data: List<ZonaWireVideoSource> = emptyList(),
    val collation: String? = null,
)

@Serializable
data class ZonaWireMoviesResponse(
    val total: Long = 0L,
    val data: List<ZonaWireMovieSummary> = emptyList(),
    val collation: String? = null,
)

/**
 * Partial projection only. Unknown movie fields can be ignored by Json when
 * configured with ignoreUnknownKeys=true. This is not the full original Movie.
 */
@Serializable
data class ZonaWireMovieSummary(
    val id: Long = 0L,
    val name: String? = null,
    val coverUrl: String? = null,
    val year: String? = null,
    val description: String? = null,
    val quality: String? = null,
    val genres: String? = null,
    val countries: String? = null,
    val zonaRating: String? = null,
    val imdbRating: String? = null,
    val originalName: String? = null,
    val duration: String? = null,
    val serial: Boolean? = null,
)

/** Converts the recovered stream DTO into the UI/playback boundary model. */
fun ZonaWireStreamInfo.toLumiStreamInfoOrNull(): LumiStreamInfo? {
    val streamUrl = url?.takeIf {
        it.startsWith("https://", ignoreCase = true) ||
            it.startsWith("http://", ignoreCase = true)
    } ?: return null

    val subtitles = subtitleList.mapNotNull { subtitle ->
        val subtitleUrl = subtitle.url?.takeIf {
            it.startsWith("https://", ignoreCase = true) ||
                it.startsWith("http://", ignoreCase = true)
        } ?: return@mapNotNull null
        LumiSubtitle(
            name = subtitle.name?.takeIf(String::isNotBlank)
                ?: subtitle.language?.takeIf(String::isNotBlank)
                ?: "Субтитры",
            language = subtitle.language,
            url = subtitleUrl,
            mimeType = when (subtitle.codec?.lowercase()) {
                "vtt", "webvtt" -> "text/vtt"
                "srt", "subrip" -> "application/x-subrip"
                else -> null
            }
        )
    }

    val mime = when {
        streamUrl.substringBefore('?').endsWith(".m3u8", ignoreCase = true) -> "application/x-mpegURL"
        streamUrl.substringBefore('?').endsWith(".mpd", ignoreCase = true) -> "application/dash+xml"
        streamUrl.substringBefore('?').endsWith(".mp4", ignoreCase = true) -> "video/mp4"
        codec.equals("hls", ignoreCase = true) -> "application/x-mpegURL"
        codec.equals("dash", ignoreCase = true) -> "application/dash+xml"
        else -> null
    }

    return LumiStreamInfo(
        url = streamUrl,
        language = language,
        translation = translation,
        quality = quality,
        userAgent = userAgent,
        headers = headers,
        mimeType = mime,
        subtitles = subtitles,
    )
}
