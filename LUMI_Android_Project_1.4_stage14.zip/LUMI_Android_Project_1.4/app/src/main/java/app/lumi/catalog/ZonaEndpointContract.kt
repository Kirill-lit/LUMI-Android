package app.lumi.catalog

/**
 * Endpoint names and request field names recovered from zona5.apk DEX bytecode
 * and Kotlin serialization descriptors. This is a contract index, not a claim
 * that the routes are currently reachable or that all HTTP verbs are known.
 */
enum class ZonaHttpVerb { GET, POST, PUT, DELETE, UNKNOWN }

data class ZonaEndpointSpec(
    val path: String,
    val requestType: String? = null,
    val requestFields: List<String> = emptyList(),
    val verb: ZonaHttpVerb = ZonaHttpVerb.UNKNOWN,
    val requestEncoding: String = "unresolved",
    val notes: String = "",
)

object ZonaEndpointContract {
    /** Hosts found as literal URL strings in the APK; do not assume every host serves every route. */
    val embeddedHostCandidates: List<String> = listOf(
        "https://apir0.mzona.net",
        "https://apirn1.mzona.net",
        "https://apiw0.mzona.net",
        "https://apiwn1.mzona.net",
        "https://vsr01.zonasearch.com",
        "https://vsw01.zonasearch.com",
        "https://sync.zonasearch.com",
    )

    val endpoints: List<ZonaEndpointSpec> = listOf(
        ZonaEndpointSpec("/getMovieIds", "GetPageParams", listOf("page", "filter", "installerPackage"), requestEncoding = "params query: URL-encoded serialized JSON"),
        ZonaEndpointSpec("/getSerialIds", "GetPageParams", listOf("page", "filter", "installerPackage"), requestEncoding = "params query: URL-encoded serialized JSON"),
        ZonaEndpointSpec("/getMetadata", notes = "Route literal found in endpoint registry; request schema unresolved."),
        ZonaEndpointSpec("/getVideoSources", "GetVideoSourcesParams", listOf("kinopoiskId", "episodeKey", "movieSourceTypes", "trailer", "userInfo", "installerPackage"), requestEncoding = "params query after additional transform; unresolved", notes = "Do not call with the generic builder until zh.o.a transformation is recovered."),
        ZonaEndpointSpec("/getEpisodes", "GetEpisodesParams", listOf("entityId"), requestEncoding = "params query: URL-encoded serialized JSON"),
        ZonaEndpointSpec("/getMovieOrSerialById", "GetEntityByIdParams", listOf("id", "occupancy", "installerPackage"), requestEncoding = "params query: URL-encoded serialized JSON"),
        ZonaEndpointSpec("/getEntityByLink", "GetEntityByLinkParams", listOf("link"), requestEncoding = "params query: URL-encoded serialized JSON"),
        ZonaEndpointSpec("/getEntitiesByPerson", "GetEntitiesByPersonParams", listOf("personId", "occupancy"), requestEncoding = "params query: URL-encoded serialized JSON"),
        ZonaEndpointSpec("/getMovieOrSerialSuggests", "GetSuggests", listOf("query", "timeoutMs"), requestEncoding = "params query: URL-encoded serialized JSON"),
        ZonaEndpointSpec("/getUiCollectionPage", "GetEntityCollections", listOf("movieSourceTypes", "installerPackage"), requestEncoding = "params query: URL-encoded serialized JSON"),
        ZonaEndpointSpec("/getTvChannels", notes = "Route literal found in a repository method; parameter schema unresolved."),
        ZonaEndpointSpec("/getEntityShareUrl", notes = "Route literal found; request DTO fields not yet decoded."),
        ZonaEndpointSpec("/getTime", verb = ZonaHttpVerb.GET, notes = "Route is assembled by a request builder; verb inferred from the request call pattern, verify before production use."),
        ZonaEndpointSpec("/getUpdate", verb = ZonaHttpVerb.GET, requestFields = listOf("app_type", "versionCode"), requestEncoding = "separate query parameters", notes = "Query parameter names are directly present in UpdateZonaApiImpl.getUpdate."),
    )

    fun find(path: String): ZonaEndpointSpec? = endpoints.firstOrNull { it.path == path }
}
