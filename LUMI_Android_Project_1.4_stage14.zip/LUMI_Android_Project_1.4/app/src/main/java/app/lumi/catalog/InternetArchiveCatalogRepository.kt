package app.lumi.catalog

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Live catalogue backed by Internet Archive's public read-only APIs.
 *
 * Search results are restricted to records that declare a Creative Commons
 * license URL. Playback resolves to a media file belonging to that item.
 * This repository does not access Zona endpoints or bypass DRM/access controls.
 */
class InternetArchiveCatalogRepository : CatalogRepository {
    override suspend fun featured(): List<LumiTitle> = withContext(Dispatchers.IO) {
        searchInternal("")
    }

    override suspend fun search(query: String): List<LumiTitle> = withContext(Dispatchers.IO) {
        searchInternal(query)
    }

    override suspend fun details(id: String): LumiTitle? = withContext(Dispatchers.IO) {
        val identifier = id.removePrefix("ia:")
        if (!isValidIdentifier(identifier)) return@withContext null
        val root = JSONObject(httpGet("$BASE_URL/metadata/$identifier"))
        val metadata = root.optJSONObject("metadata") ?: return@withContext null
        val license = metadata.optString("licenseurl")
        if (!isCreativeCommonsLicense(license)) return@withContext null
        val title = metadata.optString("title").takeIf { it.isNotBlank() && it != "null" } ?: identifier
        val year = metadata.optString("year").takeIf { it.matches(Regex("\\d{4}")) }.orEmpty()
        LumiTitle(
            id = identifier,
            title = title,
            subtitle = listOfNotNull(year.takeIf(String::isNotBlank), licenseLabel(license)).joinToString(" · "),
            year = year,
            posterUrl = "$BASE_URL/services/img/$identifier",
            description = stripHtml(metadata.optString("description")).take(1200),
            sourceUrl = "$BASE_URL/details/$identifier",
            licenseUrl = license,
        )
    }

    override suspend fun streams(id: String, episodeId: String?): List<LumiStreamInfo> =
        withContext(Dispatchers.IO) {
            val identifier = id.removePrefix("ia:")
            require(isValidIdentifier(identifier)) { "Некорректный идентификатор Internet Archive." }
            val metadata = JSONObject(httpGet("$BASE_URL/metadata/$identifier"))
            val license = metadata.optJSONObject("metadata")?.optString("licenseurl").orEmpty()
            if (!isCreativeCommonsLicense(license)) {
                throw IOException("У материала нет подтверждённой лицензии Creative Commons.")
            }
            val files = metadata.optJSONArray("files") ?: JSONArray()
            val candidates = (0 until files.length()).mapNotNull { index ->
                val file = files.optJSONObject(index) ?: return@mapNotNull null
                val name = file.optString("name").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                if (file.optString("private").equals("true", ignoreCase = true)) return@mapNotNull null
                val mime = mediaMimeType(name) ?: return@mapNotNull null
                val size = file.optString("size").toLongOrNull() ?: Long.MAX_VALUE
                MediaCandidate(name, mime, size, rankMedia(name, mime))
            }.sortedWith(compareBy<MediaCandidate> { it.rank }.thenBy { it.size })

            val candidate = candidates.firstOrNull()
                ?: throw IOException("В этом материале не найден поддерживаемый видеофайл.")
            val encodedName = candidate.name.split('/').joinToString("/") { encode(it) }
            listOf(
                LumiStreamInfo(
                    url = "$BASE_URL/download/$identifier/$encodedName",
                    language = null,
                    translation = "Internet Archive · Creative Commons",
                    quality = null,
                    userAgent = USER_AGENT,
                    mimeType = candidate.mimeType,
                )
            )
        }

    private fun searchInternal(query: String): List<LumiTitle> {
        val cleaned = sanitizeSearch(query)
        val q = buildString {
            append("mediatype:movies AND licenseurl:http*creativecommons.org*")
            if (cleaned.isNotBlank()) {
                val terms = cleaned.split(Regex("\\s+")).filter(String::isNotBlank).take(8)
                if (terms.isNotEmpty()) {
                    append(" AND title:(")
                    append(terms.joinToString(" AND ") { "\"$it\"" })
                    append(')')
                }
            }
        }
        val fields = listOf("identifier", "title", "year", "description", "licenseurl", "creator")
        val params = buildList {
            add("q" to q)
            fields.forEach { add("fl[]" to it) }
            add("rows" to "40")
            add("page" to "1")
            add("output" to "json")
        }.joinToString("&") { (key, value) -> "${encode(key)}=${encode(value)}" }
        val root = JSONObject(httpGet("$BASE_URL/advancedsearch.php?$params"))
        val response = root.optJSONObject("response") ?: throw IOException("Каталог вернул ответ неизвестного формата.")
        val docs = response.optJSONArray("docs") ?: JSONArray()
        return (0 until docs.length()).mapNotNull { index ->
            val doc = docs.optJSONObject(index) ?: return@mapNotNull null
            val identifier = doc.optString("identifier").takeIf(::isValidIdentifier)
                ?: return@mapNotNull null
            val license = doc.optString("licenseurl")
            if (!isCreativeCommonsLicense(license)) return@mapNotNull null
            val title = doc.optString("title").takeIf { it.isNotBlank() && it != "null" } ?: identifier
            val year = doc.optString("year").takeIf { it.matches(Regex("\\d{4}")) }.orEmpty()
            val creator = doc.optString("creator").takeIf { it.isNotBlank() && it != "null" }
            val description = stripHtml(doc.optString("description")).take(1200)
            LumiTitle(
                id = identifier,
                title = title,
                subtitle = listOfNotNull(year.takeIf(String::isNotBlank), licenseLabel(license)).joinToString(" · "),
                year = year,
                posterUrl = "$BASE_URL/services/img/$identifier",
                kind = TitleKind.MOVIE,
                description = description,
                stream = null,
                sourceUrl = "$BASE_URL/details/$identifier",
                licenseUrl = license,
            )
        }.distinctBy { it.id }
    }

    private fun httpGet(urlString: String): String {
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10_000
                readTimeout = 15_000
                instanceFollowRedirects = true
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", USER_AGENT)
            }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_RESPONSE_BYTES) throw IOException("Ответ каталога слишком большой.")
                    output.write(buffer, 0, count)
                }
                output.toString(StandardCharsets.UTF_8.name())
            }.orEmpty()
            if (status !in 200..299) throw IOException("Internet Archive вернул HTTP $status.")
            return body
        } finally {
            connection?.disconnect()
        }
    }

    private data class MediaCandidate(
        val name: String,
        val mimeType: String,
        val size: Long,
        val rank: Int,
    )

    companion object {
        private const val BASE_URL = "https://archive.org"
        private const val USER_AGENT = "LUMI Android media catalogue (public Creative Commons items)"
        private const val MAX_RESPONSE_BYTES = 4 * 1024 * 1024

        internal fun isValidIdentifier(value: String): Boolean =
            value.matches(Regex("[A-Za-z0-9_-]{1,100}"))

        internal fun isCreativeCommonsLicense(value: String): Boolean =
            value.startsWith("https://creativecommons.org/", ignoreCase = true) ||
                value.startsWith("http://creativecommons.org/", ignoreCase = true)

        internal fun licenseLabel(value: String): String {
            val path = value.substringAfter("creativecommons.org/", "").trim('/')
            val parts = path.split('/')
            return when {
                parts.size >= 3 && parts[0] == "licenses" -> {
                    val code = parts[1].uppercase().replace("BY", "BY")
                    "CC $code ${parts[2]}"
                }
                parts.size >= 3 && parts[0] == "publicdomain" ->
                    "Public Domain ${parts[1].replaceFirstChar { it.uppercase() }} ${parts[2]}"
                else -> "Creative Commons"
            }
        }

        internal fun mediaMimeType(name: String): String? = when (name.substringAfterLast('.', "").lowercase()) {
            "mp4", "m4v" -> "video/mp4"
            "m3u8" -> "application/x-mpegURL"
            "mpd" -> "application/dash+xml"
            "webm" -> "video/webm"
            "ogv" -> "video/ogg"
            else -> null
        }

        private fun rankMedia(name: String, mime: String): Int = when {
            name.endsWith(".mp4", ignoreCase = true) -> 0
            name.endsWith(".m3u8", ignoreCase = true) -> 1
            name.endsWith(".webm", ignoreCase = true) -> 2
            name.endsWith(".mpd", ignoreCase = true) -> 3
            else -> 4
        }

        private fun sanitizeSearch(value: String): String =
            value.take(100).replace(Regex("[^\\p{L}\\p{N}\\s-]"), " ").trim()

        private fun stripHtml(value: String): String =
            value.replace(Regex("(?is)<script.*?</script>"), " ")
                .replace(Regex("(?is)<style.*?</style>"), " ")
                .replace(Regex("<[^>]+>"), " ")
                .replace("&nbsp;", " ", ignoreCase = true)
                .replace("&amp;", "&", ignoreCase = true)
                .replace("&quot;", "\"", ignoreCase = true)
                .replace(Regex("\\s+"), " ")
                .trim()

        private fun encode(value: String): String =
            URLEncoder.encode(value, StandardCharsets.UTF_8.name()).replace("+", "%20")
    }
}
