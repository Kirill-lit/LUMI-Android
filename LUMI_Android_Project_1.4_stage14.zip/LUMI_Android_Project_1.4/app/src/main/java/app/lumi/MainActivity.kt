package app.lumi

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.MimeTypes
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.platform.LocalContext
import app.lumi.catalog.InternetArchiveCatalogRepository
import app.lumi.catalog.LumiTitle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive

private val Graphite = Color(0xFF101215)
private val Panel = Color(0xFF1B1F24)
private val Panel2 = Color(0xFF242A31)
private val Accent = Color(0xFFC6D0DA)
private val Muted = Color(0xFF929BA5)
private val White = Color(0xFFF4F6F8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LumiApp() }
    }
}

@Composable
private fun LumiApp() {
    var tab by remember { mutableStateOf("Главная") }
    var playing by remember { mutableStateOf<PlaybackRequest?>(null) }
    var showUrlDialog by remember { mutableStateOf(false) }
    var streamUrl by remember { mutableStateOf("") }
    var contentId by remember { mutableStateOf("custom-stream") }
    var seriesId by remember { mutableStateOf("") }
    var featuredItems by remember { mutableStateOf<List<LumiTitle>>(emptyList()) }
    var searchItems by remember { mutableStateOf<List<LumiTitle>>(emptyList()) }
    var catalogStatus by remember { mutableStateOf("Загружаем каталог с лицензиями Creative Commons…") }
    var searchStatus by remember { mutableStateOf("Поиск по каталогу Internet Archive") }
    var isResolvingStream by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var libraryRevision by remember { mutableIntStateOf(0) }
    var searchRequestId by remember { mutableIntStateOf(0) }

    val repository = remember { InternetArchiveCatalogRepository() }
    val context = LocalContext.current
    val playbackStore = remember { PlaybackStore(context) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        runCatching { repository.featured() }
            .onSuccess { items ->
                featuredItems = items
                searchItems = items
                catalogStatus = if (items.isEmpty()) {
                    "Каталог ответил, но лицензированные материалы не найдены. Попробуйте обновить."
                } else {
                    "Загружено ${items.size} материалов с Creative Commons-лицензией."
                }
            }
            .onFailure { error ->
                catalogStatus = "Не удалось загрузить каталог: ${error.message ?: "ошибка сети"}"
            }
    }

    val playTitle: (LumiTitle) -> Unit = { title ->
        scope.launch {
            isResolvingStream = true
            try {
                val stream = repository.streams(title.id).firstOrNull()
                    ?: throw IllegalStateException("Для этого материала не найден видеопоток.")
                playing = PlaybackRequest(
                    id = title.id,
                    title = title.title,
                    url = stream.url,
                    seriesId = title.seriesId,
                    userAgent = stream.userAgent,
                    headers = stream.headers,
                    mimeType = stream.mimeType,
                )
            } catch (error: Exception) {
                notice = "Не удалось открыть «${title.title}»: ${error.message ?: "ошибка потока"}"
            } finally {
                isResolvingStream = false
            }
        }
    }

    val openSource: (LumiTitle) -> Unit = { title ->
        val url = title.sourceUrl
        if (url != null && url.startsWith("https://archive.org/")) {
            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                .onFailure { notice = "Не удалось открыть страницу источника." }
        } else {
            notice = "Для этого материала нет ссылки на страницу источника."
        }
    }

    val runSearch: (String) -> Unit = { query ->
        searchRequestId += 1
        val requestId = searchRequestId
        scope.launch {
            searchStatus = if (query.isBlank()) "Загружаем подборку…" else "Ищем «$query»…"
            runCatching {
                if (query.isBlank()) repository.featured() else repository.search(query)
            }.onSuccess { results ->
                if (requestId == searchRequestId) {
                    searchItems = results
                    searchStatus = "Найдено: ${results.size}"
                }
            }.onFailure { error ->
                if (requestId == searchRequestId) {
                    searchStatus = "Ошибка поиска: ${error.message ?: "сеть недоступна"}"
                }
            }
        }
    }

    val latestHistory = playbackStore.recentHistory().firstOrNull()
    val allItems = (featuredItems + searchItems).distinctBy { it.id }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Graphite, surface = Panel, primary = Accent, onBackground = White,
        onSurface = White, secondary = Muted
    )) {
        Surface(Modifier.fillMaxSize(), color = Graphite) {
            if (playing != null) {
                PlayerScreen(request = playing!!, onBack = { playing = null; libraryRevision++ })
            } else {
                Scaffold(
                    containerColor = Graphite,
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF15181C), tonalElevation = 0.dp) {
                            listOf(
                                "Главная" to Icons.Default.Home,
                                "Поиск" to Icons.Default.Search,
                                "Моё" to Icons.Default.BookmarkBorder,
                                "Профиль" to Icons.Default.PersonOutline
                            ).forEach { (label, icon) ->
                                NavigationBarItem(
                                    selected = tab == label,
                                    onClick = { tab = label },
                                    icon = { Icon(icon, contentDescription = label) },
                                    label = { Text(label, fontSize = 11.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = White, selectedTextColor = White,
                                        indicatorColor = Panel2, unselectedIconColor = Muted,
                                        unselectedTextColor = Muted
                                    )
                                )
                            }
                        }
                    }
                ) { padding ->
                    when (tab) {
                        "Главная" -> HomeScreen(
                            modifier = Modifier.padding(padding),
                            onContinue = {
                                val item = latestHistory
                                if (item == null) {
                                    notice = "Сначала откройте фильм из каталога. После просмотра он появится в продолжении."
                                } else {
                                    playTitle(LumiTitle(id = item.contentId, title = item.title, seriesId = item.seriesId))
                                }
                            },
                            continueTitle = latestHistory?.title,
                            onEnterUrl = { showUrlDialog = true },
                            catalogItems = featuredItems,
                            catalogStatus = catalogStatus,
                            onRefresh = {
                                scope.launch {
                                    catalogStatus = "Обновляем каталог…"
                                    runCatching { repository.featured() }
                                        .onSuccess { featuredItems = it; catalogStatus = "Загружено ${it.size} материалов с Creative Commons-лицензией." }
                                        .onFailure { catalogStatus = "Ошибка каталога: ${it.message ?: "сеть недоступна"}" }
                                }
                            },
                            onPlayTitle = playTitle,
                            onOpenSource = openSource
                        )
                        "Поиск" -> SearchCatalogScreen(
                            items = searchItems,
                            favorites = playbackStore.favoriteIds(),
                            status = searchStatus,
                            onSearch = runSearch,
                            onFavorite = { id -> playbackStore.toggleFavorite(id); libraryRevision++ },
                            onPlayTitle = playTitle,
                            onOpenSource = openSource,
                            modifier = Modifier.padding(padding)
                        )
                        "Моё" -> MyLibraryScreen(
                            revision = libraryRevision,
                            store = playbackStore,
                            items = allItems,
                            onPlayTitle = playTitle,
                            onOpenSource = openSource,
                            onLibraryChanged = { libraryRevision++ },
                            modifier = Modifier.padding(padding)
                        )
                        else -> ProfileScreen(Modifier.padding(padding))
                    }
                }
            }
        }
    }

    if (showUrlDialog) {
        AlertDialog(
            onDismissRequest = { showUrlDialog = false },
            containerColor = Panel,
            title = { Text("Открыть видеопоток") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = contentId, onValueChange = { contentId = it }, label = { Text("ID контента для истории") }, singleLine = true)
                    OutlinedTextField(value = seriesId, onValueChange = { seriesId = it }, label = { Text("ID сериала (необязательно)") }, singleLine = true)
                    OutlinedTextField(value = streamUrl, onValueChange = { streamUrl = it }, label = { Text("URL потока (.m3u8 / .mp4)") })
                    Text("Используйте собственный поток, на который у вас есть права доступа.", color = Muted, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (streamUrl.startsWith("https://", true) || streamUrl.startsWith("http://", true)) {
                        playing = PlaybackRequest(
                            contentId.trim().ifBlank { "custom-stream" },
                            "Видеопоток",
                            streamUrl.trim(),
                            seriesId.trim().ifBlank { null },
                            mimeType = guessMimeType(streamUrl.trim())
                        )
                        showUrlDialog = false
                    } else {
                        notice = "Введите корректный URL, начинающийся с https:// или http://."
                    }
                }) { Text("Открыть") }
            },
            dismissButton = { TextButton(onClick = { showUrlDialog = false }) { Text("Отмена") } }
        )
    }

    if (isResolvingStream) {
        AlertDialog(
            onDismissRequest = {},
            containerColor = Panel,
            title = { Text("Подключение к видео") },
            text = { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator()
                Text("Получаем метаданные и проверяем доступный видеофайл…")
            } },
            confirmButton = {}
        )
    }

    notice?.let { message ->
        AlertDialog(
            onDismissRequest = { notice = null },
            containerColor = Panel,
            title = { Text("LUMI") },
            text = { Text(message) },
            confirmButton = { TextButton(onClick = { notice = null }) { Text("Понятно") } }
        )
    }
}

private data class PlaybackRequest(
    val id: String,
    val title: String,
    val url: String,
    val seriesId: String?,
    val userAgent: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val mimeType: String? = null,
)

private fun guessMimeType(url: String): String? = when {
    url.substringBefore('?').endsWith(".m3u8", ignoreCase = true) -> MimeTypes.APPLICATION_M3U8
    url.substringBefore('?').endsWith(".mpd", ignoreCase = true) -> MimeTypes.APPLICATION_MPD
    url.substringBefore('?').endsWith(".mp4", ignoreCase = true) -> MimeTypes.VIDEO_MP4
    else -> null
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    onContinue: () -> Unit,
    onEnterUrl: () -> Unit,
    continueTitle: String?,
    catalogItems: List<LumiTitle>,
    catalogStatus: String,
    onRefresh: () -> Unit,
    onPlayTitle: (LumiTitle) -> Unit,
    onOpenSource: (LumiTitle) -> Unit,
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("LUMI", fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp, color = White)
                    Text("КИНО. БЕЗ ЛИШНЕГО.", fontSize = 10.sp, letterSpacing = 2.sp, color = Muted)
                }
                Surface(shape = RoundedCornerShape(16.dp), color = Panel, modifier = Modifier.size(44.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Tune, contentDescription = "Настройки", tint = Accent) }
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth()
                    .background(Brush.linearGradient(listOf(Color(0xFF303943), Color(0xFF171A1E), Color(0xFF22272D))), RoundedCornerShape(26.dp))
                    .padding(22.dp)
            ) {
                Text("ВАШ ВЕЧЕР", color = Accent, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Text("Истории,\nкоторые остаются.", fontSize = 30.sp, lineHeight = 35.sp, fontWeight = FontWeight.SemiBold, color = White)
                Spacer(Modifier.height(12.dp))
                Text("Продолжайте там, где остановились.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                Button(onClick = onContinue, enabled = continueTitle != null, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Graphite)) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Продолжить просмотр", fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Продолжить просмотр", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("ВСЁ", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).clickable(onClick = onContinue).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(width = 112.dp, height = 76.dp).background(Brush.linearGradient(listOf(Color(0xFF49535E), Color(0xFF222830))), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PlayCircle, contentDescription = null, tint = White, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(continueTitle ?: "Ещё ничего не просмотрено", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(5.dp))
                    Text(if (continueTitle == null) "Откройте материал из каталога ниже" else "Продолжить с сохранённой позиции", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(progress = { if (continueTitle == null) 0f else 0.38f }, modifier = Modifier.fillMaxWidth().height(3.dp), color = Accent, trackColor = Panel2)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Библиотека", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Muted)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Фильмы", "Сериалы", "Избранное").forEach { title ->
                    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f).clickable(onClick = onEnterUrl)) {
                        Column(Modifier.padding(vertical = 17.dp, horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = Accent)
                            Spacer(Modifier.height(8.dp))
                            Text(title, fontSize = 12.sp, color = White)
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("Каталог фильмов", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                    Text("Internet Archive · материалы с Creative Commons-лицензией", color = Muted, fontSize = 11.sp)
                }
                IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, contentDescription = "Обновить каталог", tint = Accent) }
            }
            Text(catalogStatus, color = Muted, fontSize = 12.sp)
        }
        items(catalogItems.size) { index ->
            val title = catalogItems[index]
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp))
                    .clickable { onPlayTitle(title) }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (title.posterUrl != null) {
                    AsyncImage(
                        model = title.posterUrl,
                        contentDescription = "Постер ${title.title}",
                        modifier = Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(Modifier.size(58.dp).background(Panel2, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Movie, contentDescription = null, tint = Accent)
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text(title.subtitle.ifBlank { "Источник Internet Archive" }, color = Muted, fontSize = 12.sp)
                }
                IconButton(onClick = { onOpenSource(title) }) {
                    Icon(Icons.Default.OpenInNew, contentDescription = "Страница источника и лицензия", tint = Muted)
                }
                Icon(Icons.Default.PlayArrow, contentDescription = "Открыть", tint = Accent)
            }
        }
        item {
            OutlinedButton(onClick = onEnterUrl, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Link, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Открыть свой видеопоток")
            }
            Text("Источники и лицензии отображаются со стороны Internet Archive. Проверяйте условия лицензии на странице материала.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SearchCatalogScreen(
    items: List<LumiTitle>,
    favorites: Set<String>,
    status: String,
    onSearch: (String) -> Unit,
    onFavorite: (String) -> Unit,
    onPlayTitle: (LumiTitle) -> Unit,
    onOpenSource: (LumiTitle) -> Unit,
    modifier: Modifier = Modifier,
) {
    var query by remember { mutableStateOf("") }
    LaunchedEffect(query) {
        delay(450)
        onSearch(query)
    }
    val filtered = remember(query, items) {
        if (query.isBlank()) items else items.filter {
            it.title.contains(query.trim(), ignoreCase = true) ||
                it.description.contains(query.trim(), ignoreCase = true) ||
                it.subtitle.contains(query.trim(), ignoreCase = true)
        }
    }
    Column(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 22.dp)) {
        Text("Поиск", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true, label = { Text("Название или описание") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
        )
        Spacer(Modifier.height(12.dp))
        Text(if (query.isBlank()) status else "$status · в текущей выдаче: ${filtered.size}", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered.size) { index ->
                val title = filtered[index]
                CatalogRow(title, favorites.contains(title.id), { onPlayTitle(title) }, { onFavorite(title.id) }, { onOpenSource(title) })
            }
        }
    }
}

@Composable
private fun MyLibraryScreen(
    revision: Int,
    store: PlaybackStore,
    items: List<LumiTitle>,
    onPlayTitle: (LumiTitle) -> Unit,
    onOpenSource: (LumiTitle) -> Unit,
    onLibraryChanged: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val favorites = remember(revision) { store.favoriteIds() }
    val history = remember(revision) { store.recentHistory() }
    Column(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 22.dp)) {
        Text("Моя библиотека", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Text("Избранное", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        val favoriteItems = items.filter { favorites.contains(it.id) }
        if (favoriteItems.isEmpty()) Text("Добавляйте фильмы в избранное через значок закладки.", color = Muted, fontSize = 13.sp)
        favoriteItems.forEach { title -> CatalogRow(title, true, { onPlayTitle(title) }, { store.toggleFavorite(title.id); onLibraryChanged() }, { onOpenSource(title) }) }
        Spacer(Modifier.height(22.dp))
        Text("Недавно просмотрено", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        if (history.isEmpty()) Text("История появится после первого запуска видео.", color = Muted, fontSize = 13.sp)
        history.forEach { item ->
            val title = items.firstOrNull { it.id == item.contentId }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Panel, RoundedCornerShape(14.dp))
                    .clickable { if (title != null) onPlayTitle(title) }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.History, contentDescription = null, tint = Accent)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Сохранённая история просмотра", color = Muted, fontSize = 11.sp)
                }
                if (title != null) Icon(Icons.Default.PlayArrow, contentDescription = "Продолжить", tint = Accent)
            }
        }
    }
}

@Composable
private fun CatalogRow(title: LumiTitle, favorite: Boolean, onPlay: () -> Unit, onFavorite: () -> Unit, onOpenSource: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(Panel2).clickable(onClick = onPlay), contentAlignment = Alignment.Center) {
            if (title.posterUrl != null) {
                AsyncImage(model = title.posterUrl, contentDescription = "Постер ${title.title}", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Icon(Icons.Default.Movie, contentDescription = null, tint = Accent)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).clickable(onClick = onPlay)) {
            Text(title.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(title.subtitle.ifBlank { "Локальный источник" }, color = Muted, fontSize = 12.sp)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (favorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, contentDescription = if (favorite) "Убрать из избранного" else "В избранное", tint = Accent)
        }
        if (title.sourceUrl != null) {
            IconButton(onClick = onOpenSource) {
                Icon(Icons.Default.OpenInNew, contentDescription = "Источник и лицензия", tint = Muted)
            }
        }
        IconButton(onClick = onPlay) { Icon(Icons.Default.PlayArrow, contentDescription = "Смотреть", tint = White) }
    }
}

@Composable
private fun ProfileScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Профиль", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("LUMI · каталог открытых лицензий", color = Muted)
        Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = Accent)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Приватность")
                    Text("История, избранное и предпочтение озвучки хранятся на устройстве.", color = Muted, fontSize = 12.sp)
                }
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, contentDescription = null, tint = Accent)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("О проекте")
                    Text("Каталог загружается из Internet Archive. Воспроизведение доступно для материалов с поддерживаемыми видеофайлами.", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun PlayerScreen(request: PlaybackRequest, onBack: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val store = remember { PlaybackStore(context) }
    var selectedLanguage by remember(request.seriesId) {
        mutableStateOf(request.seriesId?.let { store.audioLanguage(it) } ?: "ru")
    }
    var status by remember { mutableStateOf("Подготовка плеера…") }
    val httpFactory = remember(request.userAgent, request.headers) {
        DefaultHttpDataSource.Factory()
            .setUserAgent(request.userAgent?.takeIf { it.isNotBlank() } ?: "LUMI/1.1")
            .setDefaultRequestProperties(request.headers)
    }
    val player = remember(request.id, request.url, request.userAgent, request.headers, request.mimeType) {
        val mediaItemBuilder = MediaItem.Builder().setUri(request.url).setMediaId(request.id)
        request.mimeType?.let(mediaItemBuilder::setMimeType)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(httpFactory))
            .build().apply {
                setMediaItem(mediaItemBuilder.build())
                val resume = store.position(request.id)
                if (resume > 0) seekTo(resume)
                playWhenReady = true
                if (request.seriesId != null) {
                    trackSelectionParameters = trackSelectionParameters
                        .buildUpon().setPreferredAudioLanguage(selectedLanguage).build()
                }
                prepare()
            }
    }
    LaunchedEffect(player, request.id) {
        store.saveHistory(request.id, request.title, request.seriesId)
        while (isActive) {
            if (player.currentPosition > 0L && player.playbackState != Player.STATE_ENDED) {
                store.savePosition(request.id, player.currentPosition)
            }
            delay(5_000)
        }
    }
    DisposableEffect(player, lifecycleOwner) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                status = when (playbackState) {
                    Player.STATE_BUFFERING -> "Загрузка…"
                    Player.STATE_READY -> "Воспроизведение готово"
                    Player.STATE_ENDED -> {
                        store.clearPosition(request.id)
                        "Просмотр завершён"
                    }
                    else -> "Подключение к потоку…"
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                status = "Ошибка потока: ${error.errorCodeName}"
            }
        }
        player.addListener(listener)
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> store.savePosition(request.id, player.currentPosition)
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            store.savePosition(request.id, player.currentPosition)
            player.removeListener(listener)
            lifecycleOwner.lifecycle.removeObserver(observer)
            player.release()
        }
    }
    Column(Modifier.fillMaxSize().background(Graphite)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Назад", tint = White) }
            Column(Modifier.weight(1f)) {
                Text(request.title, fontWeight = FontWeight.SemiBold)
                Text(status, color = Muted, fontSize = 12.sp)
            }
        }
        AndroidView(
            factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        )
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Продолжение просмотра", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            Text("Позиция для «${request.id}» сохраняется локально на устройстве.", color = Muted, fontSize = 13.sp)
            if (request.seriesId != null) {
                Text("Предпочитаемая озвучка", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("ru" to "Русская", "en" to "Оригинал").forEach { (tag, label) ->
                        FilterChip(
                            selected = selectedLanguage == tag,
                            onClick = {
                                selectedLanguage = tag
                                store.saveAudioLanguage(request.seriesId, tag)
                                player.trackSelectionParameters = player.trackSelectionParameters
                                    .buildUpon().setPreferredAudioLanguage(tag).build()
                            },
                            label = { Text(label) }
                        )
                    }
                }
                Text("Выбор языка применяется, если поток содержит соответствующую аудиодорожку.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}
