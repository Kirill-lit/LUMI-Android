package app.lumi.catalog

import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/** Builds only the confirmed `params=<URL-encoded JSON>` request shape. */
object ZonaRequestUrlBuilder {
    /**
     * Builds a URL for endpoints whose request lambda serializes the request DTO
     * and places it into the `params` query parameter. The video-source endpoint
     * is deliberately rejected until its additional `zh.o.a` transform is recovered.
     * This method does not perform network I/O.
     */
    fun buildParamsUrl(baseUrl: String, path: String, serializedParamsJson: String): String {
        val endpoint = ZonaEndpointContract.find(path)
            ?: throw IllegalArgumentException("Unknown Zona endpoint: $path")
        require(path != "/getVideoSources") {
            "The video-source endpoint applies an additional transformation that is not yet reproduced."
        }
        require(endpoint.requestType != null) {
            "Request schema for $path has not been recovered; refusing to guess its encoding."
        }
        val base = URI(baseUrl)
        require(base.scheme == "https") { "Only HTTPS base URLs are allowed." }
        require(base.host != null && ZonaEndpointContract.embeddedHostCandidates.any {
            URI(it).host.equals(base.host, ignoreCase = true)
        }) { "Base host is not one of the APK's embedded host candidates." }
        require(base.rawQuery == null && base.rawFragment == null) { "Base URL must not contain query or fragment." }
        val normalizedBase = base.toString().trimEnd('/')
        val encoded = URLEncoder.encode(serializedParamsJson, StandardCharsets.UTF_8.name())
        return "$normalizedBase$path?params=$encoded"
    }
}
