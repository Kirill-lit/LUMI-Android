package app.lumi.catalog

import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

/**
 * Decoders for the observed Zona wire DTOs.
 *
 * This is intentionally not an HTTP client: routes/authentication are not yet
 * verified. Keep transport and deserialization separate until the API contract
 * is reconstructed.
 */
object ZonaWireJson {
    val json: Json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    fun decodeMoviesResponse(body: String): ZonaWireMoviesResponse =
        json.decodeFromString(body)

    fun decodeVideoSourcesResponse(body: String): ZonaWireVideoSourcesResponse =
        json.decodeFromString(body)

    fun decodeStreamInfo(body: String): ZonaWireStreamInfo =
        json.decodeFromString(body)
}
