package app.lumi.catalog

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

/**
 * Partial request DTOs reconstructed from Kotlin serialization descriptors and
 * model constructor signatures in zona5.apk. JsonElement is used where the
 * original nested type is obfuscated and not yet safely identified.
 */
@Serializable
data class ZonaUserPremiumInfo(
    val accessToken: String? = null,
    val userId: Long? = null,
    val isPremium: Boolean = false,
)

@Serializable
data class ZonaGetVideoSourcesParams(
    val kinopoiskId: Long,
    val episodeKey: String? = null,
    val movieSourceTypes: List<JsonElement> = emptyList(),
    val trailer: Boolean? = null,
    val userInfo: ZonaUserPremiumInfo? = null,
    val installerPackage: String? = null,
)

@Serializable
data class ZonaGetEpisodesParams(
    val entityId: Long,
)

@Serializable
data class ZonaGetEntityByIdParams(
    val id: String,
    /** Original enum type is obfuscated; preserve the wire value until enum mapping is recovered. */
    val occupancy: String? = null,
    val installerPackage: String? = null,
)

@Serializable
data class ZonaGetEntityByLinkParams(
    val link: String,
)

@Serializable
data class ZonaGetEntitiesByPersonParams(
    val personId: Long,
    val occupancy: String? = null,
)

@Serializable
data class ZonaGetSuggestsParams(
    val query: String,
    val timeoutMs: Long? = null,
)

@Serializable
data class ZonaGetPageParams(
    /** The original page/filter classes are obfuscated; keep their JSON shapes caller-defined. */
    val page: JsonElement? = null,
    val filter: JsonElement? = null,
    val installerPackage: String? = null,
)

@Serializable
data class ZonaGetEntityCollectionsParams(
    @SerialName("movieSourceTypes") val movieSourceTypes: List<JsonElement> = emptyList(),
    val installerPackage: String? = null,
)
