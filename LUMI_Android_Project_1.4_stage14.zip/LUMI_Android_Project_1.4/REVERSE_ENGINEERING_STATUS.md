# LUMI reverse-engineering status

Current LUMI project metadata: **1.2.0 (versionCode 12)**. Earlier 0.6 metadata below describes a historical checkpoint, not the current app configuration.

## Confirmed from the supplied Zona APK

- Four DEX files are present.
- Kotlin serialization descriptors expose real field keys for `Movie`, `Episode`, `VideoSource`, `StreamInfo`, `Subtitle`, and several API request/response models.
- Method-level DEX analysis ties route literals to obfuscated repository methods.
- Request DTO names and fields are recoverable for `GetVideoSourcesParams`, `GetEpisodesParams`, `GetEntityByIdParams`, `GetEntityByLinkParams`, `GetEntitiesByPersonParams`, `GetSuggests`, `GetPageParams`, and `GetEntityCollections`.
- Several request lambdas serialize their DTO and set a URL query parameter named `params`.
- The `/getVideoSources` request lambda applies an extra transform before setting `params`; this transform is not yet reproduced.
- Candidate API host strings are present in the APK, but route-to-host mapping, current availability, authentication, and failover are unverified.

## LUMI project components

- Graphite Compose prototype and Media3 player foundation.
- Local playback-position and audio-language preference storage.
- Local demo catalog, search, favorites, and history.
- Partial Zona wire response DTOs and JSON decoding.
- Endpoint registry and partial request DTOs.
- A URL builder for the observed `params` query shape; it requires HTTPS and an APK-embedded host and refuses `/getVideoSources` until its transform is recovered.
- Repeatable DEX route/host string verification script.

## Validation status

- DEX route/host verifier: **PASS** (14 route literals and 7 host literals found in the APK string pools).
- Standalone Kotlin compile/test of `ZonaEndpointContract.kt` and `ZonaRequestUrlBuilder.kt`: **PASS**.
- Full Android/Compose build: **not run** (Android SDK/Gradle unavailable in the current environment).
- Live Zona API requests: **not run**.
- Installable LUMI APK: **not produced**.

## Next technical blocker

Recover `zh.o.a(String)` and the base URL selection logic, then verify response envelopes and query serialization against representative responses. Do not hard-code a live API call until the extra video-source transform, authentication requirements, and host selection are understood.


## Stage 7 update

# LUMI 0.7 — Stage 7: request transport and transform call-site

## Concrete result

Added `ZonaApiClient.kt`, an opt-in HTTP transport for request routes whose DEX call sites show a serialized request assigned to a URL query parameter named `params`. The client:
- uses HTTPS and the existing APK-host allowlist enforced by `ZonaRequestUrlBuilder`;
- applies connect/read timeouts and disables automatic redirects;
- caps response bodies at 4 MiB;
- returns response text for later decoding;
- reports bounded HTTP error diagnostics;
- exposes `getEpisodes(entityId)` for the clearest recovered request DTO.

The client deliberately does **not** handle `/getVideoSources`, auth, host failover, or any premium/subscription logic. The project is not switched to live API by default.

## New bytecode finding: video-source parameter transform

Call-site scan confirms `rh.I.invoke(Object)` calls `zh.o.a(String)` and then writes the returned value under the literal query key `params`. The same transform is also called by `Bd.u.invokeSuspend(Object)`. The `zh.o.a(String)` body references:
- `kotlin.text.StringsKt.encodeToByteArray`;
- `kotlin.random.Random$Default.nextInt` twice (with constants corresponding to bounded random ranges);
- byte-array copy operations;
- `kotlin.io.encoding.Base64.encode$default`.

Therefore the video-source parameter is not simply the plain serialized JSON used by the generic builder. Its transformation appears randomized and Base64-related. The exact byte layout has **not** been proven, so no guessed implementation has been added.

## Verification

- Re-ran the existing DEX inventory check: 4 DEX files, all 14 documented route literals and 7 candidate host literals found.
- Added `verify_stage7_transform.py` to verify the transform callsite against the APK.
- Added source-level Kotlin unit tests for URL encoding, rejecting `/getVideoSources`, and host allowlisting.
- Full Android build and runtime API test are still not available here: Android SDK/Gradle are not installed. No live requests were sent.

## Remaining blockers

1. Fully decode `zh.o.a(String)` including byte-array offsets and Base64 parameters.
2. Recover base-host selection/failover and any required headers/auth.
3. Confirm the real HTTP verb and response wrappers with a controlled request or official server contract.
4. Connect decoded API responses to the UI only after those checks.


# LUMI 0.8 — Stage 8: isolate the video-source transform and response boundary

## What changed
- Added a DEX method inspection tool, `reverse_engineering/disassemble_stage8_targets.py`, to dump instruction offsets and method references for the transform (`zh.o.a`), its call sites (`rh.I.invoke`, `Bd.u.invokeSuspend`) and relevant `VideoSource` accessors.
- Kept the live `/getVideoSources` route disabled in `ZonaApiClient`. The previous stage established a random/Base64-related transform, but the exact byte layout must be proven before using it.
- Added a response boundary design note to prevent API wire DTOs from being treated as app-domain models without confirming response wrappers.

## Confirmed prior evidence
The APK's DEX strings and method-reference table include `/getVideoSources`, `params`, and two call sites to `zh.o.a(String)`. The transform method references byte-array conversion, random integers, byte-array copy, and Base64 encoding. This is consistent with an obfuscating or nonce-based transform, but the precise algorithm and server expectations remain unverified.

## Next technical target
Trace the arguments into `zh.o.a(String)`, recover the full instruction-level algorithm and determine whether randomness is used for a prefix/suffix, byte offsets, or key material. Then compare against any request-builder code in the APK and only implement it if all byte offsets and encoding parameters can be accounted for.

## Limitations
This is static analysis. No requests were sent to Zona servers. No Android build was run because Android SDK and Gradle are unavailable in the current environment.


# LUMI 0.9 — Stage 9: instruction-width-correct disassembly

## Work completed
The earlier Stage 8 dump was useful for locating the transform but its compact instruction walker did not define all DEX opcode widths. This stage replaces that view with a fuller DEX-width table, handles packed-switch/sparse-switch/array-data payload widths, and emits raw instruction words plus resolved string/method references for `zh.o.a`, `rh.I.invoke`, and `Bd.u.invokeSuspend`.

## Evidence retained
The transform method `zh.o.a(String)` has 103 code units and includes calls to `StringsKt.encodeToByteArray`, two `Random.Default.nextInt` calls, byte-array operations, and Base64 encoding. The two call sites remain `rh.I.invoke` and `Bd.u.invokeSuspend`. These facts support that the transformation is nontrivial; they do not by themselves establish a safe, exact reimplementation.

## Why no guessed algorithm was added
A correct implementation requires identifying each register's value, branch path, random bounds, byte-array layout, and Base64 flags from the full instruction sequence. The DEX listing is now available in `STAGE9_TARGET_DISASSEMBLY.txt` for that next manual/data-flow step. The production client continues to refuse `/getVideoSources`.

## Verification
- Re-ran the Stage 6 route/host string-pool verifier.
- Re-ran the Stage 7 call-site verifier.
- Generated a fuller raw disassembly for the three target methods.
- No live API request was sent; Android build remains unavailable in this environment.


# LUMI 1.0 — Stage 10: transform trace and reproducible analysis

## Findings
The bytecode analysis was rerun against `/mnt/data/zona5.apk`. The instruction listing is preserved in `STAGE9_TARGET_DISASSEMBLY.txt`; the focused trace for `zh.o.a(String)` and both call sites is in `STAGE10_TRANSFORM_TRACE.txt`.

The observed transform uses string-to-byte conversion, random number generation, byte-array operations and Base64. That evidence establishes the transform's ingredients, but not the exact encoding contract. The current extraction helper exposes instruction words and method references, not a full semantic DEX decompiler; register data-flow reconstruction is still required before a faithful implementation can be claimed.

## Project changes
- Version bumped to 1.0.
- Added a focused transform trace artifact to make the next manual register/data-flow pass faster.
- Preserved the safety gate: the app client must not send guessed payloads to `/getVideoSources`.
- Added an explicit API integration checklist that distinguishes proven facts from assumptions.

## Verification
- Stage 6 route/host verifier: pass.
- Stage 7 call-site verifier: pass.
- Stage 9 target-method disassembly: pass.
- No requests sent to Zona servers.
- Full Android build not performed because Android SDK/Gradle are unavailable in this environment.

## What would count as the next meaningful result
A register-by-register trace of `zh.o.a(String)` with each branch and byte offset resolved, or a verified response fixture that proves the request/response contract. Merely adding more model classes is not enough.


# LUMI 1.1 — Stage 11: fix source blockers and add reproducible Android build

## Concrete source fixes
- Replaced a literal newline inside a normal Kotlin string with the escaped `\\n` sequence.
- Removed a duplicated `@Composable` annotation above `SearchCatalogScreen`.
- Updated app version metadata to `versionCode 11` / `versionName 1.1.0`.
- Updated the player/network User-Agent labels to LUMI 1.1.
- Simplified the URL-builder unit test's expected encoded JSON string.

These were identified by inspecting the actual source files; the first two are real Kotlin source-level build blockers.

## Build route
Added `.github/workflows/android-build.yml`. On GitHub it provisions JDK 17, Android SDK 35 and Gradle 8.9, runs unit tests and `assembleDebug`, then uploads `app-debug.apk` as a downloadable workflow artifact. `BUILD_APK.md` documents the steps.

## Verification boundaries
This environment has Java but no `gradle`, `kotlinc`, Android SDK, `adb`, JADX or Apktool. Therefore I could not execute the Android compile locally, and I do not claim the APK has been built. The next real build result must come from the workflow run; its output will identify any remaining compile errors.

## API integration
No changes were made to bypass the unresolved `/getVideoSources` transform. The live Zona catalog remains unconnected.


# LUMI 1.2 — Stage 12: live licensed catalogue and media resolution

## Implemented
- Replaced the demo-only catalogue with `InternetArchiveCatalogRepository`.
- Uses Internet Archive's public Advanced Search API, restricted to movie records declaring a Creative Commons license URL.
- Loads actual item titles, years, descriptions, license-aware subtitles, and thumbnail URLs.
- Resolves each selected item through the public metadata endpoint and chooses a non-private MP4/HLS/DASH/WebM/OGV file.
- Opens the resolved media URL in the existing Media3 ExoPlayer screen.
- Added remote search with debounce, refresh, poster thumbnails, loading/error messages, and three pure unit tests for license/identifier/media-type validation.
- Kept the manual HTTP(S) stream entry for testing user-owned/authorized URLs.
- Did not connect to Zona's unresolved `/getVideoSources` transformation.

## API sources
The repository uses Internet Archive's public Advanced Search API and Item Metadata API, documented by Internet Archive. Search results are filtered by the presence of a Creative Commons license URL, and the app shows that license category. Users should still review the exact license and rights statement on each item's archive page before reuse.

## Build verification limits
This execution environment has Java 21 but no Gradle, Gradle wrapper, Android SDK, adb, Kotlin compiler, or network access to download them. Therefore no actual Android APK build or device test could be run here. Static source checks and project-level tests were added, but a successful GitHub Actions build is still required before device testing.

## Known limitations
- This is a real public/open-license catalogue, not the original Zona catalogue. Zona's stream-parameter transformation remains unresolved.
- Internet Archive records vary in metadata quality; some items may have no playable file or may be unavailable in a user's region/network.
- The UI displays a Creative Commons source label, but the exact license URL is currently not persisted in the UI model; users should check the item's Archive page.


## Stage 13 — native bridge trace (2026-10-10)

- Re-verified the newly uploaded `zona5(1).apk`; SHA-256 matches the previously inventoried APK.
- Confirmed JNI declarations and exported symbols in `libzona.so` for `CppUtil$Companion.d`, `eso`, `lof`, and time-check functions.
- Found a second `/getVideoSources` request path that calls native `CppUtil.d()` before the randomized/Base64-related `zh.o.a(String)` transform.
- See `reverse_engineering/STAGE13_NATIVE_BRIDGE_TRACE.md` for evidence and remaining unknowns.
