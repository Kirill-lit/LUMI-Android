# LUMI 0.8 — Stage 8: isolate the video-source transform and response boundary

## What changed
- Added a DEX method inspection tool, `reverse_engineering/disassemble_stage8_targets.py`, to dump instruction offsets and method references for the transform (`zh.o.a`), its call sites (`rh.I.invoke`, `Bd.u.invokeSuspend`) and relevant `VideoSource` accessors.
- Kept the live `/getVideoSources` route disabled in `ZonaApiClient`. The previous stage established a random/Base64-related transform, but the exact byte layout must be proven before using it.
- Added a response boundary design note to prevent API wire DTOs from being treated as app-domain models without confirming response wrappers.

## Confirmed prior evidence
The APK's DEX strings and method-reference table include `/getVideoSources`, `params`, and two call sites to `zh.o.a(String)`. The transform method references byte-array conversion, random integers, byte-array copy, and Base64 encoding. This is consistent with an obfuscating or nonce-based transform, but the precise algorithm and server expectations remain unverified.

## Next technical target
Trace the arguments into `zh.o.a(String)`, recover the full instruction-level algorithm and determine whether randomness is used for a prefix/suffix, byte offsets, or key material. Then compare against any request-builder code in the APK and only implement it if all byte offsets and encoding parameters can be accounted for.

## Limitations
This is static analysis. No requests were sent to Zona servers. No Android build was run because Android SDK and Gradle are unavailable in the current environment.
