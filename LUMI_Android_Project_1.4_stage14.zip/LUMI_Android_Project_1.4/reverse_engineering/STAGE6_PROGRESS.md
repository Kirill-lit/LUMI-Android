# LUMI Stage 6 — endpoint and request-contract recovery

## Significant result

A method-level DEX scan now connects endpoint literals to obfuscated repository methods and reveals several original request DTO names through Kotlin serialization descriptors. This is a stronger result than a flat list of URL strings. A second call-site inspection also identified the common request shape: several endpoint lambdas serialize a DTO and add it to a URL query parameter named `params`. The `/getVideoSources` lambda has an additional transformation call before setting `params`, so it is deliberately not handled by the generic URL builder yet.

### Endpoint-to-request mappings recovered from `classes4.dex`

| Route literal | Original request type / fields recovered | Confidence / limits |
|---|---|---|
| `/getVideoSources` | `ru.zona.content.api.GetVideoSourcesParams`: `kinopoiskId`, `episodeKey`, `movieSourceTypes`, `trailer`, `userInfo`, `installerPackage` | Route is in method `rh..a`; DTO field names and order are in serializer descriptor / `toString`. Nested list element type and wire encoding remain unresolved. |
| `/getEpisodes` | `GetEpisodesParams`: `entityId` | Route is in `rh.p.a`; DTO descriptor gives `entityId`. |
| `/getMovieOrSerialById` | `GetEntityByIdParams`: `id`, `occupancy`, `installerPackage` | Route is in `rh.e.d`; occupancy enum values are not yet recovered. |
| `/getEntityByLink` | `GetEntityByLinkParams`: `link` | Route is in `rh.m.a`. |
| `/getEntitiesByPerson` | `GetEntitiesByPersonParams`: `personId`, `occupancy` | Route is in `rh.m.f`; occupancy enum values unresolved. |
| `/getMovieOrSerialSuggests` | `GetSuggests`: `query`, `timeoutMs` | Route is in `mg.d.f`. |
| `/getMovieIds`, `/getSerialIds` | `GetPageParams`: `page`, `filter`, `installerPackage` | Shared request type inferred from calls through `rh.e`; nested `page` and `filter` schemas unresolved. |
| `/getUiCollectionPage` | `GetEntityCollections`: `movieSourceTypes`, `installerPackage` | Route is in `mg.i.b`; exact serialized model name/fields recovered. |
| `/getUpdate` | query names `app_type`, `versionCode` | Both keys and route occur in `UpdateZonaApiImpl.getUpdate`. GET is indicated by its URL/query construction pattern; should still be runtime-verified. |
| `/getMetadata`, `/getTvChannels`, `/getEntityShareUrl`, `/getTime` | Route literals and caller methods found | Request schema is incomplete; `/getTime` verb should be runtime-verified. |

### Embedded host candidates

The APK string pools contain `https://apir0.mzona.net`, `https://apirn1.mzona.net`, `https://apiw0.mzona.net`, `https://apiwn1.mzona.net`, `https://vsr01.zonasearch.com`, `https://vsw01.zonasearch.com`, and `https://sync.zonasearch.com`.

These are embedded URL strings only. The scan does not prove which host serves each endpoint, whether the service is currently available, or what failover/authentication logic is required.

## Request encoding detail recovered

For `/getEpisodes`, `/getMovieIds`, `/getSerialIds`, `/getMovieOrSerialById`, `/getEntityByLink`, `/getEntitiesByPerson`, `/getMovieOrSerialSuggests`, and `/getUiCollectionPage`, the endpoint lambdas call the serialization helper and then set the URL parameter named `params`. The request helper receives a path, a response type descriptor, and a request-builder lambda. The observed builder shape is consistent with an encoded JSON value in `params`; the project URL builder percent-encodes the JSON accordingly.

For `/getVideoSources`, the lambda serializes the `GetVideoSourcesParams` DTO, then calls `zh.o.a(String)` before assigning `params`. That extra transform has not been reproduced. LUMI's builder explicitly refuses to build this route rather than sending a malformed or incompatible request.

## Project changes

- Added `ZonaEndpointContract.kt` with route registry, recovered request keys, candidate host list, and explicit unknowns.
- Added `ZonaRequestModels.kt` with partial serializable request DTOs. `JsonElement` is used where the original nested type is obfuscated rather than guessing its schema.
- Added `ZonaRequestUrlBuilder.kt`, which builds the observed `params` query shape only for known routes/hosts, requires HTTPS, and refuses the special `/getVideoSources` transform path.
- Bumped project metadata to version `0.6.0` / versionCode `6`.
- Added `verify_stage6_contract.py`, which re-scans all DEX string pools and verifies the documented route and host literals.

## Verification performed

The verifier scans the four DEX files and checks every documented route/host literal against the actual string pools. The endpoint registry and URL builder were also compiled with `kotlinc` independently of Android, then exercised with tests for correct percent-encoding, HTTPS-only URLs, embedded-host allowlisting, and refusing `/getVideoSources`. No live API calls were made. This does not establish server reachability, authentication, full Android compilation, or a working APK.

## Remaining blocker

The generic request helper and several URL-building lambdas are now partially understood. The remaining blockers are the extra transform on `/getVideoSources`, exact response wrapper contracts for catalog results, host selection/failover, auth headers, and Android build verification. Next, inspect `zh.o.a`, determine the API base-host selection path, then build a mock transport test around real serialized request/response examples before enabling live requests.
