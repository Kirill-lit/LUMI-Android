# LUMI 1.0 — Stage 10: transform trace and reproducible analysis

## Findings
The bytecode analysis was rerun against `/mnt/data/zona5.apk`. The instruction listing is preserved in `STAGE9_TARGET_DISASSEMBLY.txt`; the focused trace for `zh.o.a(String)` and both call sites is in `STAGE10_TRANSFORM_TRACE.txt`.

The observed transform uses string-to-byte conversion, random number generation, byte-array operations and Base64. That evidence establishes the transform's ingredients, but not the exact encoding contract. The current extraction helper exposes instruction words and method references, not a full semantic DEX decompiler; register data-flow reconstruction is still required before a faithful implementation can be claimed.

## Project changes
- Version bumped to 1.0.
- Added a focused transform trace artifact to make the next manual register/data-flow pass faster.
- Preserved the safety gate: the app client must not send guessed payloads to `/getVideoSources`.
- Added an explicit API integration checklist that distinguishes proven facts from assumptions.

## Verification
- Stage 6 route/host verifier: pass.
- Stage 7 call-site verifier: pass.
- Stage 9 target-method disassembly: pass.
- No requests sent to Zona servers.
- Full Android build not performed because Android SDK/Gradle are unavailable in this environment.

## What would count as the next meaningful result
A register-by-register trace of `zh.o.a(String)` with each branch and byte offset resolved, or a verified response fixture that proves the request/response contract. Merely adding more model classes is not enough.
