# Zona APK — Stage 2: DEX symbol and data-flow inventory

Source: user-provided `zona5.apk` (22,661,369 bytes). This report is generated from DEX tables and embedded strings; it is not a full decompilation and does not prove live server availability.

## Confirmed DEX structure
- `classes.dex`: 15,025 class definitions; 65,524 method IDs; 47,925 strings.
- `classes2.dex`: 580 class definitions; 5,499 method IDs; 2,287 strings.
- `classes3.dex`: 11,790 class definitions; 65,449 method IDs; 57,580 strings.
- `classes4.dex`: 12,944 class definitions; 54,100 method IDs; 45,871 strings.
- App namespace class definitions found in DEX class tables: 170 (`mobi.zona`: 126; `ru.zona.app`: 44).

## Core model signatures recovered from DEX
### `mobi.zona.data.model.Movie`
Actors, AdsModel, Countries, CoverUrl, Description, Director, Directors, Duration, Genres, HasEpisodeKeys, Id, ImdbRating, KsRating, Liked, MovieSourceTypes, Name, OriginalName, PosterTemplate, Quality, ReleaseDateInt, ReleaseDateRus, Rels, Scenario, Serial, Short, Strid, TrailerSourceTypes, UpdatedAt, Vast, Watched, Writers, Year, ZonaRating

### `mobi.zona.data.model.Episode`
Enable, Episode, Episode_key, Mobi_link_id, Release_date, Season, Title, Watched

### `mobi.zona.data.model.VideoSource`
DownloadLinkKey, EpisodeKey, Id, Info, KinopoiskId, VideoContentTypeId, VideoSourceTypeId

### `mobi.zona.data.model.StreamInfo`
Codec, Headers, Language, Quality, SubtitleList, Trailer, Translation, UnavailableQuality, Url, UserAgent, VideoContentTypeId, VideoSourceTypeId

### `mobi.zona.data.model.Subtitle`
Codec, Language, Name, Url

### `mobi.zona.data.model.Settings`
Ads2, AnalyticUrl, Dc, Feedback, Holiday, Links, LoadAdTimeoutMs, LoadOrderTimeOutMs, LogLevel, MyTarget, MyTargetKey, NoadThreshold, PaymentEnable, PosterWidthList, Share, SyncServer, Timeout, Urls, Ve, Volume, Year, YoutubeKey

### `mobi.zona.data.model.Ads`
Backdrop, BackdropTv, CheckInstall, Device, DownloadLink, Genres, Hide, InstallOnTv, Name, Overview, PackageName, Place, Places, Poster, Screenshots, Type, Url

### `mobi.zona.data.model.response.MoviesResponse`
Collation, Data, Total

### `mobi.zona.data.model.response.VideoSourcesResponse`
Collation, Data, Total

### `mobi.zona.data.model.response.VastResponse`
Vast

## Playback and catalogue clues
- `MovieStreamService` appears in Kotlin debug/source metadata; strings include `loadStreams`, `tryReloadStream`, and stream error messages.
- `VideoSourcesServiceWithCache` and `EpisodeServiceWithCache` appear in embedded Kotlin metadata, indicating separate cached services for stream sources and episodes.
- `GetVideoSourcesParams`, `GetEpisodesParams`, `ServerResponseVideoSources`, and `ServerResponseEpisodes` appear in the DEX string pool.
- `/getVideoSources` and `/getEpisodes` appear as route fragments in the DEX string pool. These are route-name evidence, not a guarantee of public HTTP endpoints.
- `PlaybackEpisodeDto`, `StreamIdentity`, and `activeEpisode` appear in the DEX string pool, suggesting the original app distinguishes episode playback state from the movie entity.
- `Movie` has getters for ID, name, poster/cover, description, year, ratings, serial flag, watched/liked state, source types and relations.
- `StreamInfo` has getters for URL, language, translation, quality, headers, user agent, codec and subtitles.
- `Episode` exposes episode/season/title and `episode_key` / `mobi_link_id` fields.
- `VideoSource` exposes ID, info, episode key, download-link key and source/content type IDs.

## Candidate service roots embedded in the APK
- `https://apir0.mzona.net`
- `https://apirn1.mzona.net`
- `https://apiw0.mzona.net`
- `https://apiwn1.mzona.net`
- `https://az1.zona.pub/v1/auth`
- `https://imgr1.imgzona.video`
- `https://imgw1.imgzona.video`
- `https://mobi.zona/home_screen/`
- `https://mobi.zona/home_screen/channel/`
- `https://sync.zonasearch.com`
- `https://vsr01.zonasearch.com`
- `https://vsw01.zonasearch.com`

These host strings are hard-coded references in the APK, not a successful connectivity check. Do not hard-code them into LUMI until protocol, request parameters, headers, and access rules are understood.

## Advertising-related evidence
- `VAST_URL` appears in DEX strings: True.
- `noadThreshold` appears in DEX strings: True.
- `noad_threshold` appears in DEX strings: True.
- `ads2` appears in DEX strings: True.
- `fallbackOnNoAd` appears in DEX strings: True.
- `noAdCounter` appears in DEX strings: True.
- `VastResponse` appears in DEX strings: True.
- `googleads.g.doubleclick.net` appears in DEX strings: True.
- `imasdk.googleapis.com` appears in DEX strings: True.

## Next integration milestone
1. Inspect the call sites behind the service names and identify actual request/response contracts.
2. Recreate only the needed DTOs in LUMI, starting with movie/episode/source metadata.
3. Implement a repository boundary so UI and player do not depend on Zona internals.
4. Connect the player to a real `StreamInfo.url`, preserve required headers/user-agent, and apply saved language only when a matching audio track exists.
5. Keep ad UI absent in LUMI, but do not disable arbitrary network calls until they are distinguished from catalogue/playback dependencies.

## Tooling limitation
A DEX table parser was used to extract class names and signatures. This is deeper than a string inventory, but it does not reconstruct Kotlin method bodies. Full method-level recovery still requires JADX/another decompiler and an Android build environment.