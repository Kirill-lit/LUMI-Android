#!/usr/bin/env python3
"""Verify the /getVideoSources request-lambda calls zh.o.a(String) before setting params."""
import importlib.util, sys, zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
apk = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/mnt/data/zona5.apk")
spec = importlib.util.spec_from_file_location("dexextract", root / "tools_extract_dex_methods.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

with zipfile.ZipFile(apk) as z:
    dex_names = [n for n in z.namelist() if n.endswith(".dex") and "/" not in n]
    all_strings = set()
    method_refs = []
    for dn in dex_names:
        strings, methods, classes, blob = mod.parse(z.read(dn))
        all_strings.update(strings)
        if dn != "classes4.dex":
            continue
        target_ids = [i for i, m in enumerate(methods)
                      if m[0] == "zh.o" and m[1] == "a"
                      and m[2][0] == "Ljava/lang/String;"
                      and m[2][1] == ["java.lang.String"]]
        if not target_ids:
            raise SystemExit("FAIL: zh.o.a(String) not found")
        target_id = target_ids[0]
        callsites = []
        for owner, members in classes:
            for method, code_off, access in members:
                if not code_off:
                    continue
                regs, ins, outs, tries, dbg, size = __import__("struct").unpack_from("<HHHHII", blob, code_off)
                units = __import__("struct").unpack_from("<" + "H" * size, blob, code_off + 16)
                i = 0
                while i < size:
                    word = units[i]
                    op = word & 0xff
                    width = mod.W.get(op, 1)
                    if op == 0 and word in (0x0100, 0x0200, 0x0300):
                        if word == 0x0100: width = 4 + units[i+1] * 2
                        elif word == 0x0200: width = 2 + units[i+1] * 4
                        else: width = 4 + ((units[i+1] + 1) // 2) * 2
                    if op in list(range(0x6e, 0x73)) + list(range(0x74, 0x79)) and i + 1 < size:
                        if units[i+1] == target_id:
                            callsites.append((owner, method[1]))
                    i += max(1, width)
        method_refs.extend(callsites)

print("DEX files:", len(dex_names))
print("zh.o.a(String) callsites:", len(method_refs))
for owner, method in method_refs:
    print(f"  {owner}.{method}")
if not any(owner == "rh.I" and method == "invoke" for owner, method in method_refs):
    raise SystemExit("FAIL: expected getVideoSources lambda callsite not found")
if "params" not in all_strings or "/getVideoSources" not in all_strings:
    raise SystemExit("FAIL: endpoint or params literal missing")
print("PASS: transform callsite and params/route literals confirmed.")
