# Stage 14 — inspect the native `CppUtil.d()` bridge

## Input
- APK: `zona5(1).apk`
- SHA-256: `354cb3b0a6da060eee42bebee384a159aad075475295346c68d2c816a7c18a20`
- Native library: `lib/arm64-v8a/libzona.so`
- ELF Build ID: `37b9daad76d9cacc8fa5f1954d409343ef5a7bd2`

## New concrete result
The ARM64 JNI wrapper for `Java_mobi_zona_utils_CppUtil_00024Companion_d` was disassembled and saved in `native/arm64-jni-d-disassembly.txt`.

Observed at the wrapper level:
- It obtains a pointer from a global slot via PC-relative addressing.
- It invokes an indirect function associated with that global object.
- It passes the resulting native character data through a JNI string-creation call (`JNIEnv` function-table offset `0x538`).
- It handles the native string's small-string/heap representation and releases heap storage when needed.
- Stack-canary checks protect the return path.

This is consistent with `d()` exposing a native-held string to Kotlin. It does **not** reveal the returned string's value or prove its purpose. The exact native data object is not statically initialized as a directly readable string at this call site; resolving its initialization and the target of the indirect call is still required. No secret, key, or token value is inferred from the method name.

## Effect on request reconstruction
The known call path remains:
1. serialize the request object;
2. on the `Bd.u.invokeSuspend` path, obtain a string from `CppUtil.d()`;
3. pass a string to `zh.o.a(String)`;
4. write the transformed output into query parameter `params`.

The DEX method `zh.o.a(String)` includes UTF-8 byte conversion, two bounded random draws, byte-array operations/copies, and Base64 encoding. We still do not have a register-accurate proof of the full byte layout, nor a verified response fixture. Therefore the `/getVideoSources` call remains deliberately disabled in LUMI.

## Verification
- Rechecked APK SHA-256.
- Confirmed `libzona.so` is a stripped AArch64 ELF shared object.
- Confirmed the exported JNI symbol for `CppUtil.d()` and extracted its instruction listing.
- Re-ran project static checks and DEX endpoint/call-site checks; results are recorded in `STAGE14_VERIFICATION.txt`.

## Not done
- No requests sent to Zona servers.
- No authentication, DRM, subscription, or access-control bypass attempted.
- No Android build performed; this environment still has no Gradle installation, Android SDK, or adb.
