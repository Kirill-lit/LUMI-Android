#!/usr/bin/env python3
"""Static LUMI project preflight. This does not replace Gradle/Android compilation."""
from pathlib import Path
import sys, xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
errors = []
checks = []

def check(name, condition, detail=""):
    checks.append((name, bool(condition), detail))
    if not condition:
        errors.append(f"{name}: {detail or 'failed'}")

# Project/build configuration
check("root Gradle settings", (root/"settings.gradle.kts").exists())
check("app Gradle config", (root/"app/build.gradle.kts").exists())
check("manifest", (root/"app/src/main/AndroidManifest.xml").exists())
check("build workflow", (root/".github/workflows/android-build.yml").exists())
check("real catalogue source", (root/"app/src/main/java/app/lumi/catalog/InternetArchiveCatalogRepository.kt").exists())

gradle = (root/"app/build.gradle.kts").read_text()
main = (root/"app/src/main/java/app/lumi/MainActivity.kt").read_text()
repo = (root/"app/src/main/java/app/lumi/catalog/InternetArchiveCatalogRepository.kt").read_text()
manifest = (root/"app/src/main/AndroidManifest.xml").read_text()
workflow = (root/".github/workflows/android-build.yml").read_text()

check("compile SDK 35", "compileSdk = 35" in gradle)
check("Java 17 bytecode", 'jvmTarget = "17"' in gradle)
check("Media3 player dependencies", "androidx.media3:media3-exoplayer" in gradle and "androidx.media3:media3-ui" in gradle)
check("poster dependency", "io.coil-kt:coil-compose" in gradle)
check("internet permission", "android.permission.INTERNET" in manifest)
check("demo repo not wired to main UI", "DemoCatalogRepository" not in main)
check("live repository wired", "InternetArchiveCatalogRepository" in main)
check("real search wired", "onSearch = runSearch" in main)
check("stream metadata resolution wired", "repository.streams(title.id)" in main)
check("licensed-only query", "licenseurl:http*creativecommons.org*" in repo)
check("source link allowlisted", 'url.startsWith("https://archive.org/")' in main)
check("CI compiles and tests", "clean testDebugUnitTest assembleDebug" in workflow)
check("CI uploads APK", "app/build/outputs/apk/debug/app-debug.apk" in workflow)

try:
    ET.parse(root/"app/src/main/AndroidManifest.xml")
    xml_ok = True
except Exception as e:
    xml_ok = False
    errors.append(f"Manifest XML parse: {e}")
check("manifest XML parses", xml_ok)

# Basic lexical guard: no normal quoted Kotlin string crosses a physical newline.
def multiline_strings(text):
    i = 0
    line = 1
    problems = []
    while i < len(text):
        if text[i] == "\n":
            line += 1; i += 1; continue
        if text.startswith('"""', i):
            end = text.find('"""', i + 3)
            if end < 0:
                problems.append(line); break
            line += text[i:end+3].count("\n")
            i = end + 3
            continue
        if text[i] == '"':
            start = line; j = i + 1; escaped = False
            while j < len(text):
                c = text[j]
                if c == "\n":
                    problems.append(start); break
                if c == '"' and not escaped:
                    j += 1; break
                if c == "\\" and not escaped: escaped = True
                else: escaped = False
                j += 1
            line += text[i:j].count("\n")
            i = j
        else:
            i += 1
    return problems

kotlin_files = list(root.rglob("*.kt"))
bad = {str(p.relative_to(root)): multiline_strings(p.read_text()) for p in kotlin_files}
bad = {k:v for k,v in bad.items() if v}
check("Kotlin ordinary-string newlines", not bad, repr(bad) if bad else f"{len(kotlin_files)} files scanned")

for name, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'} | {name}" + (f" — {detail}" if detail else ""))
print(f"\nStatic checks: {sum(ok for _,ok,_ in checks)}/{len(checks)} passed")
print("WARNING: this script does not compile Kotlin or run Android/Gradle tests.")
if errors:
    print("\n".join(errors), file=sys.stderr)
    sys.exit(1)
