#!/usr/bin/env python3
"""Verify the Stage 14 APK/native bridge evidence is present and reproducible."""
from pathlib import Path
import hashlib, subprocess, zipfile, sys

root = Path(__file__).resolve().parents[1]
apk_candidates = [Path('/mnt/data/zona5(1).apk'), Path('/mnt/data/zona5.apk')]
apk = next((p for p in apk_candidates if p.is_file()), None)
if apk is None:
    print('SKIP: original APK is not in /mnt/data; provide zona5.apk to rerun full checks')
    sys.exit(0)
expected = '354cb3b0a6da060eee42bebee384a159aad075475295346c68d2c816a7c18a20'
actual = hashlib.sha256(apk.read_bytes()).hexdigest()
assert actual == expected, f'APK fingerprint mismatch: {actual}'
with zipfile.ZipFile(apk) as z:
    names = set(z.namelist())
    assert 'classes4.dex' in names
    assert 'lib/arm64-v8a/libzona.so' in names
    native = z.read('lib/arm64-v8a/libzona.so')
    assert b'Java_mobi_zona_utils_CppUtil_00024Companion_d' in native
    print('PASS | APK SHA-256 matches recorded fingerprint')
    print('PASS | classes4.dex and ARM64 libzona.so exist')
    print('PASS | JNI d() export is present')
report = root / 'reverse_engineering/STAGE14_NATIVE_D_ANALYSIS.md'
disassembly = root / 'reverse_engineering/native/arm64-jni-d-disassembly.txt'
assert report.is_file() and disassembly.is_file()
assert 'JNIEnv' in report.read_text() and 'Java_mobi_zona_utils_CppUtil_00024Companion_d' in disassembly.read_text()
print('PASS | Stage 14 analysis and disassembly artifacts present')
