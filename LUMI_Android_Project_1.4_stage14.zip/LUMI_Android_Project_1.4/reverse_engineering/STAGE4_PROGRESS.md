# Stage 4 — local library functionality and mapping tests

## Delivered in the LUMI source tree

- Replaced the placeholder Search screen with local search across title, subtitle, and description.
- Added persistent favourites backed by SharedPreferences. Favourites are available from Search and My Library.
- Replaced the placeholder My Library screen with a favourites section and recent-playback history.
- Known demo entries can be opened from the history list.
- Added a small profile/privacy screen explaining that playback history and preferences remain local.
- Kept the live Zona API disconnected: extracted route fragments and server names do not establish a complete, safe request contract.

## Validation actually run

Compiled `CatalogModels.kt` and `ZonaModelMapping.kt` with Kotlin/JVM compiler 1.9.0 and ran a focused test harness. The following checks passed:

1. `.m3u8` URLs map to HLS MIME type.
2. `.mpd` URLs map to DASH MIME type.
3. `file://` video URLs are rejected by the network-stream mapper.
4. HTTP request headers survive DTO conversion.
5. Invalid local subtitle URLs are filtered.
6. WebVTT subtitle MIME type is mapped correctly.

Result: `PASS: HLS/DASH MIME, local URL rejection, headers, subtitle filtering and MIME`.

## Not claimed

- The Android application as a whole has not been compiled.
- No installable APK has been produced or tested on a device.
- Search and favourites currently operate on the offline demo catalogue, not the Zona server.
- History can reopen an entry only when the entry exists in the currently available catalogue; persisted arbitrary source URLs are not stored in history.
