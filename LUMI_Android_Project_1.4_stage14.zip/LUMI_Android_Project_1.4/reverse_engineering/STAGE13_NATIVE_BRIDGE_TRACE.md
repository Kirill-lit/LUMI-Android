# Stage 13 — native bridge and fresh APK verification

## Input verification
- Uploaded file: `zona5(1).apk`
- SHA-256: `354cb3b0a6da060eee42bebee384a159aad075475295346c68d2c816a7c18a20`
- APK ZIP structure opens successfully; the DEX/native-library inventory is readable.
- The SHA-256 matches the hash recorded in the earlier inventory for `zona5.apk`; the uploaded file is the same binary content under a new filename.

## New concrete finding: JNI bridge
`classes4.dex` declares these native methods on `mobi.zona.utils.CppUtil$Companion`:
- `d(): String`
- `eso(): String`
- `lof(String): Int`
- `checkTimeNative(Context, long, String): String`
- `checkTimeNative2(Context, long, String): String`

The APK includes `libzona.so` for `arm64-v8a`, `armeabi-v7a`, and `x86` (among other ABI libraries). Its exported JNI symbols include `Java_mobi_zona_utils_CppUtil_00024Companion_d`, `..._eso`, `..._lof`, and the two time-check functions.

## Call-chain evidence
- The `rh.I.invoke(Object)` request lambda serializes a request object, calls `zh.o.a(String)`, and places the returned string into the `params` query parameter.
- `zh.o.a(String)` invokes `kotlin.text.StringsKt.encodeToByteArray`, `Random.Default.nextInt` twice, byte-array operations, and `Base64.encode$default`.
- The `Bd.u.invokeSuspend(Object)` path first calls `mobi.zona.utils.CppUtil$Companion.d(): String`, then passes its result to `zh.o.a(String)` before writing `params`.
- The native JNI function exists and is stripped at the ELF symbol/debug-info level; a disassembly of the exported wrapper alone does not establish the native algorithm or server contract.

## Interpretation and implementation decision
This establishes that the `/getVideoSources` parameter pipeline is not simply JSON URL-encoding. One call path incorporates a native-produced string before the randomized/Base64-related transform. The exact semantics, register-level transform, host selection, and server response contract are still not proven. LUMI therefore continues to fail closed for this endpoint rather than issue speculative requests.

## Validation performed in this stage
- Re-read the newly uploaded APK and confirmed the recorded hash.
- Re-ran the existing instruction-width-aware DEX inspection against the uploaded file.
- Extracted `libzona.so` for ARM64 and confirmed its ELF architecture and exported JNI bridge symbols with `readelf`/`llvm-objdump`.

## Not done
- No live requests were sent to Zona servers.
- No DRM, authentication, or access control was bypassed.
- No Android compilation or APK assembly was possible in this runtime because Gradle, Android SDK/build-tools, and adb are absent and external downloads are unavailable.
