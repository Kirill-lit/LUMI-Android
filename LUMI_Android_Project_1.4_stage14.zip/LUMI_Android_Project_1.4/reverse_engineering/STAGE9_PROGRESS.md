# LUMI 0.9 — Stage 9: instruction-width-correct disassembly

## Work completed
The earlier Stage 8 dump was useful for locating the transform but its compact instruction walker did not define all DEX opcode widths. This stage replaces that view with a fuller DEX-width table, handles packed-switch/sparse-switch/array-data payload widths, and emits raw instruction words plus resolved string/method references for `zh.o.a`, `rh.I.invoke`, and `Bd.u.invokeSuspend`.

## Evidence retained
The transform method `zh.o.a(String)` has 103 code units and includes calls to `StringsKt.encodeToByteArray`, two `Random.Default.nextInt` calls, byte-array operations, and Base64 encoding. The two call sites remain `rh.I.invoke` and `Bd.u.invokeSuspend`. These facts support that the transformation is nontrivial; they do not by themselves establish a safe, exact reimplementation.

## Why no guessed algorithm was added
A correct implementation requires identifying each register's value, branch path, random bounds, byte-array layout, and Base64 flags from the full instruction sequence. The DEX listing is now available in `STAGE9_TARGET_DISASSEMBLY.txt` for that next manual/data-flow step. The production client continues to refuse `/getVideoSources`.

## Verification
- Re-ran the Stage 6 route/host string-pool verifier.
- Re-ran the Stage 7 call-site verifier.
- Generated a fuller raw disassembly for the three target methods.
- No live API request was sent; Android build remains unavailable in this environment.
