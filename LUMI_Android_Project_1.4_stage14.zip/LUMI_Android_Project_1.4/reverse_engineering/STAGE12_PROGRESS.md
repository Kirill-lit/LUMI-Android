# LUMI 1.2 — Stage 12: live licensed catalogue and media resolution

## Implemented
- Replaced the demo-only catalogue with `InternetArchiveCatalogRepository`.
- Uses Internet Archive's public Advanced Search API, restricted to movie records declaring a Creative Commons license URL.
- Loads actual item titles, years, descriptions, exact Creative Commons license URLs/labels, source-page URLs, and thumbnail URLs.
- Resolves each selected item through the public metadata endpoint and chooses a non-private MP4/HLS/DASH/WebM/OGV file.
- Opens the resolved media URL in the existing Media3 ExoPlayer screen.
- Added remote search with debounce, refresh, poster thumbnails, loading/error messages, and three pure unit tests for license/identifier/media-type validation.
- Kept the manual HTTP(S) stream entry for testing user-owned/authorized URLs.
- Did not connect to Zona's unresolved `/getVideoSources` transformation.

## API sources
The repository uses Internet Archive's public Advanced Search API and Item Metadata API, documented by Internet Archive. Search results are filtered by the presence of a Creative Commons license URL, and the app shows that license category. Users should still review the exact license and rights statement on each item's archive page before reuse.

## Build verification limits
This execution environment has Java 21 but no Gradle, Gradle wrapper, Android SDK, adb, Kotlin compiler, or network access to download them. Therefore no actual Android APK build or device test could be run here. Static source checks and project-level tests were added, but a successful GitHub Actions build is still required before device testing.

## Known limitations
- This is a real public/open-license catalogue, not the original Zona catalogue. Zona's stream-parameter transformation remains unresolved.
- Internet Archive records vary in metadata quality; some items may have no playable file or may be unavailable in a user's region/network.
- The UI displays a Creative Commons source label, but the exact license URL is currently not persisted in the UI model; users should check the item's Archive page.


## Hard-check pass available in this environment
- Added `reverse_engineering/preflight_check.py`; it validates the Android manifest XML, essential build config, network permission, real catalogue/player wiring, source-link allowlisting, and checks Kotlin files for the known newline-in-string source error.
- Added a fourth unit test for human-readable CC license labels.
- CI runs on pushes, pull requests, or manual dispatch and uploads build/test reports even if the build fails.
- Static preflight passes. Actual Kotlin compilation, unit-test execution, APK assembly and device playback remain unverified because this environment has no Gradle/Gradle wrapper, Android SDK, Kotlin compiler, adb, or outbound network.
