#!/usr/bin/env python3
"""Re-checks recovered route/host literals against the supplied Zona APK."""
import importlib.util, zipfile, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
APK = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/mnt/data/zona5.apk')
spec = importlib.util.spec_from_file_location('dexextract', ROOT / 'tools_extract_dex_methods.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
with zipfile.ZipFile(APK) as z:
    dexes = [n for n in z.namelist() if n.endswith('.dex') and '/' not in n]
    all_strings = set()
    for name in dexes:
        strings, _, _, _ = mod.parse(z.read(name))
        all_strings.update(strings)
expected_routes = {
    '/getMovieIds', '/getSerialIds', '/getMetadata', '/getVideoSources',
    '/getEpisodes', '/getMovieOrSerialById', '/getEntityByLink',
    '/getEntitiesByPerson', '/getMovieOrSerialSuggests', '/getUiCollectionPage',
    '/getTvChannels', '/getEntityShareUrl', '/getTime', '/getUpdate'
}
expected_hosts = {
    'https://apir0.mzona.net', 'https://apirn1.mzona.net',
    'https://apiw0.mzona.net', 'https://apiwn1.mzona.net',
    'https://vsr01.zonasearch.com', 'https://vsw01.zonasearch.com',
    'https://sync.zonasearch.com'
}
missing_routes = sorted(expected_routes - all_strings)
missing_hosts = sorted(expected_hosts - all_strings)
print(f'DEX files scanned: {len(dexes)}')
print(f'Route literals verified: {len(expected_routes)-len(missing_routes)}/{len(expected_routes)}')
print(f'Host literals verified: {len(expected_hosts)-len(missing_hosts)}/{len(expected_hosts)}')
if missing_routes: print('Missing routes:', ', '.join(missing_routes))
if missing_hosts: print('Missing hosts:', ', '.join(missing_hosts))
if missing_routes or missing_hosts: raise SystemExit(1)
print('PASS: all documented route and host literals exist in DEX string pools.')
