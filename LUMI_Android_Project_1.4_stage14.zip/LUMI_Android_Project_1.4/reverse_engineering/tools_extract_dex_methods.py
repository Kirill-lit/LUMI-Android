import zipfile, struct, os, sys
APK='/mnt/data/zona5.apk'

def uleb(b,p):
 r=0;s=0
 while True:
  x=b[p];p+=1;r|=(x&127)<<s
  if x<128:return r,p
  s+=7

def parse(b):
 def U32(o): return struct.unpack_from('<I',b,o)[0]
 def U16(o): return struct.unpack_from('<H',b,o)[0]
 ns,so=U32(56),U32(60); nt,to=U32(64),U32(68); np,po=U32(72),U32(76); nm,mo=U32(88),U32(92); nc,co=U32(96),U32(100)
 strings=[]
 for i in range(ns):
  off=U32(so+i*4); _,q=uleb(b,off); e=b.index(0,q); strings.append(b[q:e].decode('utf8','replace'))
 types=[strings[U32(to+i*4)] for i in range(nt)]
 protos=[]
 for i in range(np):
  o=po+i*12; shorty=strings[U32(o)]; ret=types[U32(o+4)]; io=U32(o+8); args=[]
  if io:
   n=U32(io); args=[types[U16(io+4+j*2)] for j in range(n)]
  protos.append((ret,args))
 methods=[]
 for i in range(nm):
  o=mo+i*8; ci=U16(o); pi=U16(o+2); ni=U32(o+4); methods.append((types[ci].strip('L;').replace('/', '.'),strings[ni],(protos[pi][0], [a.strip('L;').replace('/', '.') for a in protos[pi][1]])))
 classes=[]
 for i in range(nc):
  o=co+i*32; ci=U32(o); cdata=U32(o+24); cname=types[ci].strip('L;').replace('/', '.'); ms=[]
  if cdata:
   p=cdata
   sf,p=uleb(b,p); inf,p=uleb(b,p); dm,p=uleb(b,p); vm,p=uleb(b,p)
   for count in (sf,inf):
    idx=0
    for _ in range(count): idxd,p=uleb(b,p); acc,p=uleb(b,p); idx+=idxd
   for count in (dm,vm):
    idx=0
    for _ in range(count):
     idxd,p=uleb(b,p); acc,p=uleb(b,p); code,p=uleb(b,p); idx+=idxd
     ms.append((methods[idx],code,acc))
  classes.append((cname,ms))
 return strings,methods,classes,b

# DEX instruction widths in 16-bit code units. Unlisted valid opcodes default to 1.
W={0x02:2,0x03:3,0x05:2,0x06:3,0x08:2,0x09:3,0x13:2,0x14:3,0x15:2,0x16:2,0x17:3,0x19:2,0x1a:2,0x1b:3,0x1c:2,0x1f:2,0x20:2,0x22:2,0x23:2,0x24:3,0x25:3,0x26:3,0x29:2,0x2a:3,0x2b:3,0x2c:3}
for x in range(0x32,0x3e): W[x]=2
for x in range(0x44,0x6e): W[x]=2
for x in range(0x6e,0x73): W[x]=3
W.update({0x74:3,0x75:3,0x76:3,0x77:3,0x78:3,0xfa:4,0xfb:4,0xfc:3,0xfd:3,0xfe:2,0xff:2})
# packed/sparse/fill-array payload widths handled specially

def inspect(apk):
 out=[]
 with zipfile.ZipFile(apk) as z:
  dexes=[n for n in z.namelist() if n.endswith('.dex') and '/' not in n]
  targets=('ru.zona.app.stream.movie.MovieStreamService','ru.zona.app.services.VideoSourcesServiceWithCache','ru.zona.app.services.EpisodeServiceWithCache','mobi.zona.data.model.Movie','mobi.zona.data.model.StreamInfo','ru.zona.client.api.entity.impl.VideoSourcesService','ru.zona.client.api.entity.impl.EpisodeService','mobi.zona.data.UpdateZonaApiImpl','ru.zona.app.android.MainActivity','ru.zona.app.services.download.StreamDownloadWorker')
  for dn in dexes:
   b=z.read(dn); strings,methods,classes,_=parse(b); out.append(f'## {dn}')
   mref={i:m for i,m in enumerate(methods)}
   sref={i:s for i,s in enumerate(strings)}
   for cname,ms in classes:
    if not (cname in targets or any(cname.startswith(t+'$') for t in targets) or ('MovieStreamService' in cname) or ('VideoSourcesServiceWithCache' in cname) or ('EpisodeServiceWithCache' in cname)):
     continue
    out.append(f'### {cname}')
    for (owner,name,(ret,args)),code,acc in ms:
     if not code: continue
     regs,ins,outs,tries,dbg,sz=struct.unpack_from('<HHHHII',b,code)
     p=code+16; insns=list(struct.unpack_from('<'+'H'*sz,b,p)); strings_found=[]; calls=[]
     i=0
     while i<sz:
      w=insns[i]; op=w&255; width=W.get(op,1)
      if op==0x00 and w in (0x0100,0x0200,0x0300):
       if w==0x0100: width=4+insns[i+1]*2
       elif w==0x0200: width=2+insns[i+1]*4
       else: width=4+((insns[i+1]+1)//2)*2
      if op==0x1a and i+1<sz: strings_found.append(sref.get(insns[i+1],f'<string#{insns[i+1]}>'))
      elif op==0x1b and i+2<sz:
       ix=insns[i+1]|(insns[i+2]<<16); strings_found.append(sref.get(ix,f'<string#{ix}>'))
      elif op in (0x6e,0x6f,0x70,0x71,0x72,0x74,0x75,0x76,0x77,0x78) and i+1<sz:
       ix=insns[i+1]; calls.append(mref.get(ix, f'<method#{ix}>'))
      i+=max(1,width)
     out.append(f'- `{name}({", ".join(args)}) -> {ret}` regs={regs} code_units={sz}')
     if strings_found: out.append('  strings: '+ ' | '.join(dict.fromkeys(strings_found))[:700])
     if calls: out.append('  calls: '+ ' ; '.join(f'{c[0]}->{c[1]}' for c in { (c[0], c[1]): c for c in calls }.values())[:1200])
 return '\n'.join(out)

if __name__=='__main__': print(inspect(sys.argv[1] if len(sys.argv) > 1 else APK))
