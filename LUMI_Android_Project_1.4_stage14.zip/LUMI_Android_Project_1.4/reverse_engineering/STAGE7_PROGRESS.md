# LUMI 0.7 — Stage 7: request transport and transform call-site

## Concrete result

Added `ZonaApiClient.kt`, an opt-in HTTP transport for request routes whose DEX call sites show a serialized request assigned to a URL query parameter named `params`. The client:
- uses HTTPS and the existing APK-host allowlist enforced by `ZonaRequestUrlBuilder`;
- applies connect/read timeouts and disables automatic redirects;
- caps response bodies at 4 MiB;
- returns response text for later decoding;
- reports bounded HTTP error diagnostics;
- exposes `getEpisodes(entityId)` for the clearest recovered request DTO.

The client deliberately does **not** handle `/getVideoSources`, auth, host failover, or any premium/subscription logic. The project is not switched to live API by default.

## New bytecode finding: video-source parameter transform

Call-site scan confirms `rh.I.invoke(Object)` calls `zh.o.a(String)` and then writes the returned value under the literal query key `params`. The same transform is also called by `Bd.u.invokeSuspend(Object)`. The `zh.o.a(String)` body references:
- `kotlin.text.StringsKt.encodeToByteArray`;
- `kotlin.random.Random$Default.nextInt` twice (with constants corresponding to bounded random ranges);
- byte-array copy operations;
- `kotlin.io.encoding.Base64.encode$default`.

Therefore the video-source parameter is not simply the plain serialized JSON used by the generic builder. Its transformation appears randomized and Base64-related. The exact byte layout has **not** been proven, so no guessed implementation has been added.

## Verification

- Re-ran the existing DEX inventory check: 4 DEX files, all 14 documented route literals and 7 candidate host literals found.
- Added `verify_stage7_transform.py` to verify the transform callsite against the APK.
- Added source-level Kotlin unit tests for URL encoding, rejecting `/getVideoSources`, and host allowlisting.
- Full Android build and runtime API test are still not available here: Android SDK/Gradle are not installed. No live requests were sent.

## Remaining blockers

1. Fully decode `zh.o.a(String)` including byte-array offsets and Base64 parameters.
2. Recover base-host selection/failover and any required headers/auth.
3. Confirm the real HTTP verb and response wrappers with a controlled request or official server contract.
4. Connect decoded API responses to the UI only after those checks.
