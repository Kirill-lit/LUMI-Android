#!/usr/bin/env python3
"""Instruction-width-aware DEX listing for selected methods. No source-code claims are inferred."""
import importlib.util, struct, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APK = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/mnt/data/zona5.apk")
spec = importlib.util.spec_from_file_location("dexparser", ROOT / "tools_extract_dex_methods.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

W = {}
W.update({x:1 for x in list(range(0x00,0x02))+list(range(0x04,0x05))+list(range(0x07,0x08))+list(range(0x0a,0x13))})
W.update({0x02:2,0x03:3,0x05:2,0x06:3,0x08:2,0x09:3})
W.update({0x13:2,0x14:3,0x15:2,0x16:2,0x17:3,0x18:5,0x19:2,0x1a:2,0x1b:3,0x1c:2,0x1d:1,0x1e:1,0x1f:2,0x20:2,0x21:1,0x22:2,0x23:2,0x24:3,0x25:3,0x26:3,0x27:1,0x28:1,0x29:2,0x2a:3,0x2b:3,0x2c:3})
for x in range(0x2d,0x32): W[x]=2
for x in range(0x32,0x3e): W[x]=2
for x in range(0x44,0x6e): W[x]=2
for x in list(range(0x6e,0x73))+list(range(0x74,0x79)): W[x]=3
for x in range(0x7b,0x90): W[x]=1
for x in range(0x90,0xb0): W[x]=2
for x in range(0xb0,0xd0): W[x]=1
for x in range(0xd0,0xe3): W[x]=2
W.update({0xfa:4,0xfb:4,0xfc:3,0xfd:3,0xfe:2,0xff:2})

def u32(b, off): return struct.unpack_from("<I", b, off)[0]

def main():
    with zipfile.ZipFile(APK) as z:
        dex_names = [n for n in z.namelist() if n.endswith(".dex") and "/" not in n]
        output=[]
        for dn in dex_names:
            strings, methods, classes, blob = mod.parse(z.read(dn))
            for owner, members in classes:
                for meth, code_off, access in members:
                    if owner not in {"zh.o", "rh.I", "Bd.u"}:
                        continue
                    if meth[1] not in {"a", "invoke", "invokeSuspend"} or not code_off:
                        continue
                    if owner == "zh.o" and meth[1] != "a":
                        continue
                    if owner == "rh.I" and meth[1] != "invoke":
                        continue
                    if owner == "Bd.u" and meth[1] != "invokeSuspend":
                        continue
                    regs, ins, outs, tries, dbg, size = struct.unpack_from("<HHHHII", blob, code_off)
                    units = struct.unpack_from("<" + "H"*size, blob, code_off+16)
                    output.append(f"\n=== {dn}: {owner}.{meth[1]} proto={meth[2]} ===")
                    output.append(f"registers={regs} incoming={ins} outgoing={outs} code_units={size}")
                    i=0
                    while i<size:
                        word=units[i]; op=word & 0xff
                        if op==0 and word in (0x0100,0x0200,0x0300):
                            if word==0x0100:
                                n=units[i+1]; width=4+n*2
                            elif word==0x0200:
                                n=units[i+1]; width=2+n*4
                            else:
                                elem_width=units[i+1]; n=units[i+2] | (units[i+3]<<16)
                                width=4+(elem_width*n+1)//2
                            output.append(f"{i:04d}: PAYLOAD ident=0x{word:04x} width={width}")
                            i += width
                            continue
                        width=W.get(op,1)
                        words=units[i:i+width]
                        detail=f"{i:04d}: op=0x{op:02x} words="+" ".join(f"{x:04x}" for x in words)
                        if op==0x1a and width>=2:
                            sid=units[i+1]
                            detail += f" string[{sid}]={strings[sid]!r}" if sid<len(strings) else f" string[{sid}]=<bad>"
                        elif op==0x1b and width>=3:
                            sid=units[i+1] | (units[i+2]<<16)
                            detail += f" string[{sid}]={strings[sid]!r}" if sid<len(strings) else f" string[{sid}]=<bad>"
                        if op in list(range(0x6e,0x73))+list(range(0x74,0x79))+[0xfa,0xfb,0xfc,0xfd]:
                            if len(words)>=2:
                                mid=words[1]
                                if mid<len(methods):
                                    m=methods[mid]
                                    detail += f" call={m[0]}.{m[1]} {m[2]}"
                        # Decode conditional and goto offsets where applicable.
                        if op in list(range(0x28,0x2b)) and len(words)>=1:
                            off=struct.unpack("<h",struct.pack("<H",words[0]>>8))[0] if op!=0x2a else None
                            if op==0x28: detail += f" branch={off}"
                            elif op==0x29: detail += f" branch={struct.unpack('<h',struct.pack('<H',words[1]))[0]}"
                            else:
                                off=struct.unpack("<i",struct.pack("<I",words[1] | (words[2]<<16)))[0]
                                detail += f" branch={off}"
                        output.append(detail)
                        i += max(1,width)
        text="\n".join(output)+"\n"
        print(text)
        (ROOT/"STAGE9_TARGET_DISASSEMBLY.txt").write_text(text)

if __name__=="__main__":
    main()
