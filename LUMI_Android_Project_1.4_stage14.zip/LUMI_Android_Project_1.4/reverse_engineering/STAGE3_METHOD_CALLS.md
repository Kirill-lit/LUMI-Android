## classes.dex
## classes2.dex
## classes3.dex
## classes4.dex
### mobi.zona.data.UpdateZonaApiImpl$getUpdate$1
- `<init>(mobi.zona.data.UpdateZonaApiImpl, kotlin.coroutines.Continuation) -> V` regs=3 code_units=6
  calls: kotlin.coroutines.jvm.internal.ContinuationImpl-><init>
- `invokeSuspend(java.lang.Object) -> Ljava/lang/Object;` regs=4 code_units=18
  calls: mobi.zona.data.UpdateZonaApiImpl->getUpdate
### mobi.zona.data.UpdateZonaApiImpl
- `<init>(java.lang.String, s9.b) -> V` regs=3 code_units=8
  calls: java.lang.Object-><init>
- `getUpdate(java.lang.String, I, kotlin.coroutines.Continuation) -> Ljava/lang/Object;` regs=13 code_units=283
  strings: call to 'resume' before 'invoke' with coroutine | /getUpdate | app_type | versionCode
  calls: mobi.zona.data.UpdateZonaApiImpl$getUpdate$1-><init> ; kotlin.coroutines.intrinsics.IntrinsicsKt->getCOROUTINE_SUSPENDED ; kotlin.ResultKt->throwOnFailure ; java.lang.IllegalStateException-><init> ; Z.k->a ; G9.f-><init> ; 9.N->b ; 9.b0->e ; java.lang.String->valueOf ; I9.m-><init> ; kotlin.coroutines.jvm.internal.SpillingKt->nullOutSpilledVariable ; I9.m->c ; mobi.zona.data.model.Update$Companion->serializer ; I9.h->b ; Da.c->c
### mobi.zona.data.model.Movie$$serializer
- `<clinit>() -> V` regs=4 code_units=186
  strings: mobi.zona.data.model.Movie | id | name | coverUrl | year | description | quality | trailerSourceTypes | movieSourceTypes | genres | countries | zonaRating | imdbRating | ksRating | director | directors | scenario | strid | writers | releaseDateInt | releaseDateRus | actors | originalName | duration | rels | serial | isLiked | isWatched | isHasEpisodeKeys | updatedAt | short | posterTemplate | vast | adsModel
  calls: mobi.zona.data.model.Movie$$serializer-><init> ; Ca.D0-><init> ; Ca.D0->l
- `<init>() -> V` regs=1 code_units=4
  calls: java.lang.Object-><init>
- `childSerializers() -> [Lya/c;` regs=37 code_units=297
  calls: mobi.zona.data.model.Movie->access$get$childSerializers$cp ; za.a->a ; kotlin.Lazy->getValue
- `deserialize(Ba.e) -> Ljava/lang/Object;` regs=2 code_units=5
  calls: mobi.zona.data.model.Movie$$serializer->deserialize
- `deserialize(Ba.e) -> Lmobi/zona/data/model/Movie;` regs=116 code_units=2210
  calls: Ba.e->b ; mobi.zona.data.model.Movie->access$get$childSerializers$cp ; Ba.c->t ; Ba.c->g0 ; Ba.c->l ; kotlin.Lazy->getValue ; Ba.c->x ; Ba.c->i ; ya.z-><init>
- `getDescriptor() -> LAa/f;` regs=2 code_units=3
- `serialize(Ba.f, java.lang.Object) -> V` regs=3 code_units=6
  calls: mobi.zona.data.model.Movie$$serializer->serialize
- `serialize(Ba.f, mobi.zona.data.model.Movie) -> V` regs=4 code_units=13
  calls: Ba.f->b ; mobi.zona.data.model.Movie->write$Self$ru_zona_ru_zona_content_models_release ; Ba.d->c
- `typeParametersSerializers() -> [Lya/c;` regs=2 code_units=3
### mobi.zona.data.model.Movie$Companion
- `<init>() -> V` regs=1 code_units=4
  calls: java.lang.Object-><init>
- `<init>(kotlin.jvm.internal.DefaultConstructorMarker) -> V` regs=2 code_units=4
  calls: mobi.zona.data.model.Movie$Companion-><init>
- `serializer() -> Lya/c;` regs=2 code_units=3
### mobi.zona.data.model.Movie
- `<clinit>() -> V` regs=9 code_units=195
  calls: mobi.zona.data.model.Movie$Companion-><init> ; Ga.p-><init> ; kotlin.LazyKt->lazy ; Ga.q-><init> ; Ga.r-><init> ; Ga.s-><init> ; java.lang.Object-><init>
- `<init>(I, I, J, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.util.List, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.Boolean, Z, Z, Z, J, Z, java.lang.String, Z, mobi.zona.data.model.Ads, Ca.O0) -> V` regs=42 code_units=251
  calls: mobi.zona.data.model.Movie$$serializer->getDescriptor ; java.util.ArrayList-><init> ; Aa.f->e ; java.util.ArrayList->add ; Aa.f->i ; ya.d-><init> ; java.lang.Object-><init>
- `<init>(J, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.util.List, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.Boolean, Z, Z, Z, J, Z, java.lang.String, Z, mobi.zona.data.model.Ads) -> V` regs=36 code_units=108
  calls: java.lang.Object-><init>
- `<init>(J, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.util.List, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.Boolean, Z, Z, Z, J, Z, java.lang.String, Z, mobi.zona.data.model.Ads, I, I, kotlin.jvm.internal.DefaultConstructorMarker) -> V` regs=77 code_units=139
  calls: mobi.zona.data.model.Movie-><init>
- `_childSerializers$_anonymous_() -> Lya/c;` regs=2 code_units=12
  calls: za.a->a ; Ca.f-><init>
- `_childSerializers$_anonymous_$0() -> Lya/c;` regs=2 code_units=12
  calls: za.a->a ; Ca.f-><init>
- `_childSerializers$_anonymous_$1() -> Lya/c;` regs=2 code_units=12
  calls: za.a->a ; Ca.f-><init>
- `_childSerializers$_anonymous_$2() -> Lya/c;` regs=2 code_units=12
  calls: za.a->a ; Ca.f-><init>
- `_childSerializers$_anonymous_$3() -> Lya/c;` regs=2 code_units=8
  calls: Ca.f-><init>
- `_childSerializers$_anonymous_$4() -> Lya/c;` regs=2 code_units=12
  calls: za.a->a ; Ca.f-><init>
- `a() -> Lya/c;` regs=1 code_units=5
  calls: mobi.zona.data.model.Movie->_childSerializers$_anonymous_$4
- `access$get$childSerializers$cp() -> [Lkotlin/Lazy;` regs=1 code_units=3
- `b() -> Lya/c;` regs=1 code_units=5
  calls: mobi.zona.data.model.Movie->_childSerializers$_anonymous_
- `c() -> Lya/c;` regs=1 code_units=5
  calls: mobi.zona.data.model.Movie->_childSerializers$_anonymous_$0
- `copy$default(mobi.zona.data.model.Movie, J, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.util.List, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.Boolean, Z, Z, Z, J, Z, java.lang.String, Z, mobi.zona.data.model.Ads, I, I, java.lang.Object) -> Lmobi/zona/data/model/Movie;` regs=58 code_units=510
- `d() -> Lya/c;` regs=1 code_units=5
  calls: mobi.zona.data.model.Movie->_childSerializers$_anonymous_$2
- `e() -> Lya/c;` regs=1 code_units=5
  calls: mobi.zona.data.model.Movie->_childSerializers$_anonymous_$3
- `f() -> Lya/c;` regs=1 code_units=5
  calls: mobi.zona.data.model.Movie->_childSerializers$_anonymous_$1
- `write$Self$ru_zona_ru_zona_content_models_release(mobi.zona.data.model.Movie, Ba.d, Aa.f) -> V` regs=11 code_units=361
  calls: Ba.d->Z ; Ba.d->u ; kotlin.Lazy->getValue ; Ba.d->r ; Ba.d->w
- `component1() -> J` regs=3 code_units=3
- `component10() -> Ljava/lang/String;` regs=2 code_units=3
- `component11() -> Ljava/lang/String;` regs=2 code_units=3
- `component12() -> Ljava/lang/String;` regs=2 code_units=3
- `component13() -> Ljava/lang/String;` regs=2 code_units=3
- `component14() -> Ljava/lang/String;` regs=2 code_units=3
- `component15() -> Ljava/util/List;` regs=2 code_units=3
- `component16() -> Ljava/lang/String;` regs=2 code_units=3
- `component17() -> Ljava/lang/String;` regs=2 code_units=3
- `component18() -> Ljava/util/List;` regs=2 code_units=3
- `component19() -> Ljava/lang/String;` regs=2 code_units=3
- `component2() -> Ljava/lang/String;` regs=2 code_units=3
- `component20() -> Ljava/lang/String;` regs=2 code_units=3
- `component21() -> Ljava/util/List;` regs=2 code_units=3
- `component22() -> Ljava/lang/String;` regs=2 code_units=3
- `component23() -> Ljava/lang/String;` regs=2 code_units=3
- `component24() -> Ljava/util/List;` regs=2 code_units=3
- `component25() -> Ljava/lang/Boolean;` regs=2 code_units=3
- `component26() -> Z` regs=2 code_units=3
- `component27() -> Z` regs=2 code_units=3
- `component28() -> Z` regs=2 code_units=3
- `component29() -> J` regs=3 code_units=3
- `component3() -> Ljava/lang/String;` regs=2 code_units=3
- `component30() -> Z` regs=2 code_units=3
- `component31() -> Ljava/lang/String;` regs=2 code_units=3
- `component32() -> Z` regs=2 code_units=3
- `component33() -> Lmobi/zona/data/model/Ads;` regs=2 code_units=3
- `component4() -> Ljava/lang/String;` regs=2 code_units=3
- `component5() -> Ljava/lang/String;` regs=2 code_units=3
- `component6() -> Ljava/lang/String;` regs=2 code_units=3
- `component7() -> Ljava/util/List;` regs=2 code_units=3
- `component8() -> Ljava/util/List;` regs=2 code_units=3
- `component9() -> Ljava/lang/String;` regs=2 code_units=3
- `copy(J, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.util.List, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.lang.String, java.util.List, java.lang.Boolean, Z, Z, Z, J, Z, java.lang.String, Z, mobi.zona.data.model.Ads) -> Lmobi/zona/data/model/Movie;` regs=72 code_units=72
  calls: mobi.zona.data.model.Movie-><init>
- `equals(java.lang.Object) -> Z` regs=9 code_units=352
  calls: kotlin.jvm.internal.Intrinsics->areEqual
- `getActors() -> Ljava/util/List;` regs=2 code_units=3
- `getAdsModel() -> Lmobi/zona/data/model/Ads;` regs=2 code_units=3
- `getCountries() -> Ljava/lang/String;` regs=2 code_units=3
- `getCoverUrl() -> Ljava/lang/String;` regs=2 code_units=3
- `getDescription() -> Ljava/lang/String;` regs=2 code_units=3
- `getDirector() -> Ljava/lang/String;` regs=2 code_units=3
- `getDirectors() -> Ljava/util/List;` regs=2 code_units=3
- `getDuration() -> Ljava/lang/String;` regs=2 code_units=3
- `getGenres() -> Ljava/lang/String;` regs=2 code_units=3
- `getId() -> J` regs=3 code_units=3
- `getImdbRating() -> Ljava/lang/String;` regs=2 code_units=3
- `getKsRating() -> Ljava/lang/String;` regs=2 code_units=3
- `getMovieSourceTypes() -> Ljava/util/List;` regs=2 code_units=3
- `getName() -> Ljava/lang/String;` regs=2 code_units=3
- `getOriginalName() -> Ljava/lang/String;` regs=2 code_units=3
- `getPosterTemplate() -> Ljava/lang/String;` regs=2 code_units=3
- `getQuality() -> Ljava/lang/String;` regs=2 code_units=3
- `getReleaseDateInt() -> Ljava/lang/String;` regs=2 code_units=3
- `getReleaseDateRus() -> Ljava/lang/String;` regs=2 code_units=3
- `getRels() -> Ljava/util/List;` regs=2 code_units=3
- `getScenario() -> Ljava/lang/String;` regs=2 code_units=3
- `getSerial() -> Ljava/lang/Boolean;` regs=2 code_units=3
- `getShort() -> Z` regs=2 code_units=3
- `getStrid() -> Ljava/lang/String;` regs=2 code_units=3
- `getTrailerSourceTypes() -> Ljava/util/List;` regs=2 code_units=3
- `getUpdatedAt() -> J` regs=3 code_units=3
- `getVast() -> Z` regs=2 code_units=3
- `getWriters() -> Ljava/util/List;` regs=2 code_units=3
- `getYear() -> Ljava/lang/String;` regs=2 code_units=3
- `getZonaRating() -> Ljava/lang/String;` regs=2 code_units=3
- `hashCode() -> I` regs=11 code_units=417
- `isHasEpisodeKeys() -> Z` regs=2 code_units=3
- `isLiked() -> Z` regs=2 code_units=3
- `isWatched() -> Z` regs=2 code_units=3
- `setHasEpisodeKeys(Z) -> V` regs=2 code_units=3
- `setLiked(Z) -> V` regs=2 code_units=3
- `setSerial(java.lang.Boolean) -> V` regs=2 code_units=3
- `setShort(Z) -> V` regs=2 code_units=3
- `setUpdatedAt(J) -> V` regs=3 code_units=3
- `setWatched(Z) -> V` regs=2 code_units=3
- `toString() -> Ljava/lang/String;` regs=38 code_units=364
  strings: Movie(id= | , name= | , coverUrl= | , year= | , description= | , quality= | , trailerSourceTypes= | , movieSourceTypes= | , genres= | , countries= | , zonaRating= | , imdbRating= | , ksRating= | , director= | , directors= | , scenario= | , strid= | , writers= | , releaseDateInt= | , releaseDateRus= | , actors= | , originalName= | , duration= | , rels= | , serial= | , isLiked= | , isWatched= | , isHasEpisodeKeys= | , updatedAt= | , short= | , posterTemplate= | , vast= | , adsModel= | )
  calls: java.lang.StringBuilder-><init> ; java.lang.StringBuilder->append ; 2.g->a ; M2.v->a ; java.lang.StringBuilder->toString
### mobi.zona.data.model.StreamInfo$$serializer
- `<clinit>() -> V` regs=4 code_units=81
  strings: mobi.zona.data.model.StreamInfo | url | translation | language | quality | subtitleList | userAgent | headers | unavailableQuality | isTrailer | videoSourceTypeId | videoContentTypeId | codec
  calls: mobi.zona.data.model.StreamInfo$$serializer-><init> ; Ca.D0-><init> ; Ca.D0->l
- `<init>() -> V` regs=1 code_units=4
  calls: java.lang.Object-><init>
- `childSerializers() -> [Lya/c;` regs=6 code_units=67
  calls: mobi.zona.data.model.StreamInfo->access$get$childSerializers$cp ; kotlin.Lazy->getValue
- `deserialize(Ba.e) -> Ljava/lang/Object;` regs=2 code_units=5
  calls: mobi.zona.data.model.StreamInfo$$serializer->deserialize
- `deserialize(Ba.e) -> Lmobi/zona/data/model/StreamInfo;` regs=44 code_units=370
  calls: Ba.e->b ; mobi.zona.data.model.StreamInfo->access$get$childSerializers$cp ; Ba.c->t ; Ba.c->O ; kotlin.Lazy->getValue ; Ba.c->M ; Ba.c->x ; Ba.c->X ; Ba.c->i ; ya.z-><init>
- `getDescriptor() -> LAa/f;` regs=2 code_units=3
- `serialize(Ba.f, java.lang.Object) -> V` regs=3 code_units=6
  calls: mobi.zona.data.model.StreamInfo$$serializer->serialize
- `serialize(Ba.f, mobi.zona.data.model.StreamInfo) -> V` regs=4 code_units=13
  calls: Ba.f->b ; mobi.zona.data.model.StreamInfo->write$Self$ru_zona_ru_zona_content_models_release ; Ba.d->c
- `typeParametersSerializers() -> [Lya/c;` regs=2 code_units=3
### mobi.zona.data.model.StreamInfo$Companion
- `<init>() -> V` regs=1 code_units=4
  calls: java.lang.Object-><init>
- `<init>(kotlin.jvm.internal.DefaultConstructorMarker) -> V` regs=2 code_units=4
  calls: mobi.zona.data.model.StreamInfo$Companion-><init>
- `serializer() -> Lya/c;` regs=2 code_units=3
### mobi.zona.data.model.StreamInfo
- `<clinit>() -> V` regs=5 code_units=75
  calls: mobi.zona.data.model.StreamInfo$Companion-><init> ; java.lang.Object-><init> ; kotlin.LazyKt->lazy
- `<init>(I, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.util.Map, Z, Z, I, I, java.lang.String, Ca.O0) -> V` regs=16 code_units=80
  calls: Aa.c->e ; java.lang.Object-><init>
- `<init>(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.util.Map, Z, Z, I, I, java.lang.String) -> V` regs=13 code_units=28
  calls: java.lang.Object-><init>
- `<init>(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.util.Map, Z, Z, I, I, java.lang.String, I, kotlin.jvm.internal.DefaultConstructorMarker) -> V` regs=30 code_units=63
  calls: kotlin.collections.CollectionsKt->emptyList
- `_childSerializers$_anonymous_() -> Lya/c;` regs=2 code_units=8
  calls: Ca.f-><init>
- `_childSerializers$_anonymous_$0() -> Lya/c;` regs=2 code_units=8
  calls: Ca.b0-><init>
- `a() -> Lya/c;` regs=1 code_units=5
  calls: mobi.zona.data.model.StreamInfo->_childSerializers$_anonymous_
- `access$get$childSerializers$cp() -> [Lkotlin/Lazy;` regs=1 code_units=3
- `b() -> Lya/c;` regs=1 code_units=5
  calls: mobi.zona.data.model.StreamInfo->_childSerializers$_anonymous_$0
- `copy$default(mobi.zona.data.model.StreamInfo, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.util.Map, Z, Z, I, I, java.lang.String, I, java.lang.Object) -> Lmobi/zona/data/model/StreamInfo;` regs=15 code_units=90
- `write$Self$ru_zona_ru_zona_content_models_release(mobi.zona.data.model.StreamInfo, Ba.d, Aa.f) -> V` regs=7 code_units=153
  strings: 
  calls: Ba.d->z ; Ba.d->r ; kotlin.collections.CollectionsKt->emptyList ; kotlin.jvm.internal.Intrinsics->areEqual ; kotlin.Lazy->getValue ; Ba.d->p ; Ba.d->w ; Ba.d->R
- `component1() -> Ljava/lang/String;` regs=2 code_units=3
- `component10() -> I` regs=2 code_units=3
- `component11() -> I` regs=2 code_units=3
- `component12() -> Ljava/lang/String;` regs=2 code_units=3
- `component2() -> Ljava/lang/String;` regs=2 code_units=3
- `component3() -> Ljava/lang/String;` regs=2 code_units=3
- `component4() -> Ljava/lang/String;` regs=2 code_units=3
- `component5() -> Ljava/util/List;` regs=2 code_units=3
- `component6() -> Ljava/lang/String;` regs=2 code_units=3
- `component7() -> Ljava/util/Map;` regs=2 code_units=3
- `component8() -> Z` regs=2 code_units=3
- `component9() -> Z` regs=2 code_units=3
- `copy(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.lang.String, java.util.Map, Z, Z, I, I, java.lang.String) -> Lmobi/zona/data/model/StreamInfo;` regs=26 code_units=28
  calls: mobi.zona.data.model.StreamInfo-><init>
- `equals(java.lang.Object) -> Z` regs=6 code_units=129
  calls: kotlin.jvm.internal.Intrinsics->areEqual
- `getCodec() -> Ljava/lang/String;` regs=2 code_units=3
- `getHeaders() -> Ljava/util/Map;` regs=2 code_units=3
- `getLanguage() -> Ljava/lang/String;` regs=2 code_units=3
- `getQuality() -> Ljava/lang/String;` regs=2 code_units=3
- `getSubtitleList() -> Ljava/util/List;` regs=2 code_units=3
- `getTranslation() -> Ljava/lang/String;` regs=2 code_units=3
- `getUnavailableQuality() -> Z` regs=2 code_units=3
- `getUrl() -> Ljava/lang/String;` regs=2 code_units=3
- `getUserAgent() -> Ljava/lang/String;` regs=2 code_units=3
- `getVideoContentTypeId() -> I` regs=2 code_units=3
- `getVideoSourceTypeId() -> I` regs=2 code_units=3
- `hashCode() -> I` regs=6 code_units=89
  calls: java.lang.String->hashCode ; d0.w->a ; J0.k->a ; j4.n->a
- `isTrailer() -> Z` regs=2 code_units=3
- `setUnavailableQuality(Z) -> V` regs=2 code_units=3
- `toString() -> Ljava/lang/String;` regs=16 code_units=110
  strings: , translation= | , language= | StreamInfo(url= | , quality= | , subtitleList= | , userAgent= | , headers= | , unavailableQuality= | , isTrailer= | , videoSourceTypeId= | , videoContentTypeId= | , codec= | )
  calls: J2.k->c ; 2.g->a ; java.lang.StringBuilder->append ; java.lang.StringBuilder->toString
### ru.zona.app.android.MainActivity$a
- `<init>(ru.zona.app.android.MainActivity, kotlin.coroutines.Continuation) -> V` regs=3 code_units=7
  calls: kotlin.coroutines.jvm.internal.SuspendLambda-><init>
- `create(java.lang.Object, kotlin.coroutines.Continuation) -> Lkotlin/coroutines/Continuation;` regs=5 code_units=10
  calls: ru.zona.app.android.MainActivity$a-><init>
- `invoke(java.lang.Object, java.lang.Object) -> Ljava/lang/Object;` regs=3 code_units=17
  calls: ru.zona.app.android.MainActivity$a->create ; ru.zona.app.android.MainActivity$a->invokeSuspend
- `invokeSuspend(java.lang.Object) -> Ljava/lang/Object;` regs=6 code_units=98
  strings: call to 'resume' before 'invoke' with coroutine | home_screen
  calls: kotlin.coroutines.intrinsics.IntrinsicsKt->getCOROUTINE_SUSPENDED ; kotlin.ResultKt->throwOnFailure ; java.lang.IllegalStateException-><init> ; java.lang.Object->getClass ; kotlin.text.StringsKt->r ; android.app.Activity->getApplication ; Ih.k-><init> ; kotlin.coroutines.jvm.internal.SpillingKt->nullOutSpilledVariable ; rh.m->a ; Oh.d->a
### ru.zona.app.android.MainActivity$b
- `<init>(e.a) -> V` regs=2 code_units=6
  calls: java.lang.Object-><init>
- `a(rc.I, kotlin.coroutines.jvm.internal.ContinuationImpl) -> Ljava/lang/Object;` regs=7 code_units=93
  strings: call to 'resume' before 'invoke' with coroutine
  calls: ru.zona.app.android.c-><init> ; kotlin.coroutines.intrinsics.IntrinsicsKt->getCOROUTINE_SUSPENDED ; kotlin.ResultKt->throwOnFailure ; java.lang.IllegalStateException-><init> ; e.a->g ; rc.N-><init> ; kotlin.coroutines.jvm.internal.SpillingKt->nullOutSpilledVariable ; Fg.h->b ; rc.M->a
### ru.zona.app.android.MainActivity$c
- `<init>(ig.x, Ie.a, kotlin.coroutines.Continuation) -> V` regs=4 code_units=9
  calls: kotlin.coroutines.jvm.internal.SuspendLambda-><init>
- `create(java.lang.Object, kotlin.coroutines.Continuation) -> Lkotlin/coroutines/Continuation;` regs=6 code_units=12
  calls: ru.zona.app.android.MainActivity$c-><init>
- `invoke(java.lang.Object, java.lang.Object) -> Ljava/lang/Object;` regs=3 code_units=17
  calls: ru.zona.app.android.MainActivity$c->create ; ru.zona.app.android.MainActivity$c->invokeSuspend
- `invokeSuspend(java.lang.Object) -> Ljava/lang/Object;` regs=11 code_units=182
  strings: call to 'resume' before 'invoke' with coroutine
  calls: kotlin.coroutines.intrinsics.IntrinsicsKt->getCOROUTINE_SUSPENDED ; kotlin.ResultKt->throwOnFailure ; java.lang.IllegalStateException-><init> ; ig.x->n ; java.lang.Object->getClass ; Oh.c$b->a ; ig.E->g ; ig.x->l ; Ie.b->b ; He.C->b ; He.k->D ; Oh.q->n ; kotlin.coroutines.jvm.internal.Boxing->boxLong ; java.lang.Number->longValue ; Ih.t->b ; kotlin.collections.CollectionsKt->listOfNotNull ; java.util.ArrayList-><init> ; java.lang.Iterable->iterator ; java.util.Iterator->hasNext ; java.util.Iterator->next ; kotlin.text.StringsKt->isBlank ; java.util.ArrayList->add ; kotlin.collections.CollectionsKt->emptyList
### ru.zona.app.android.MainActivity$d
- `invoke(java.lang.Object) -> Ljava/lang/Object;` regs=5 code_units=33
  strings: android.intent.action.VIEW
  calls: java.lang.Object->getClass ; android.net.Uri->parse ; android.content.Intent-><init> ; android.content.Context->startActivity ; java.lang.Throwable->printStackTrace
### ru.zona.app.android.MainActivity$e
- `<init>(kotlin.jvm.functions.Function1) -> V` regs=2 code_units=6
  calls: java.lang.Object-><init>
- `a(java.lang.Object) -> V` regs=3 code_units=6
  calls: kotlin.jvm.functions.Function1->invoke
- `equals(java.lang.Object) -> Z` regs=4 code_units=25
  calls: kotlin.jvm.internal.FunctionAdapter->getFunctionDelegate ; kotlin.jvm.internal.Intrinsics->areEqual
- `getFunctionDelegate() -> Lkotlin/Function;` regs=2 code_units=3
- `hashCode() -> I` regs=2 code_units=9
  calls: kotlin.jvm.internal.FunctionAdapter->getFunctionDelegate ; java.lang.Object->hashCode
### ru.zona.app.android.MainActivity
- `<clinit>() -> V` regs=2 code_units=17
  calls: kotlin.jvm.internal.Reflection->getOrCreateKotlinClass ; kotlin.reflect.KClass->getSimpleName ; java.lang.Object-><init>
- `<init>() -> V` regs=5 code_units=29
  calls: j.g-><init> ; Ne.a-><init> ; vd.p-><init> ; ru.zona.app.android.MainActivity$a-><init> ; Kd.d-><init>
- `q(android.content.Intent) -> Z` regs=5 code_units=69
  strings: mobi.zona | rustore | Unknown app scheme link: 
  calls: android.content.Intent->getData ; android.net.Uri->getScheme ; kotlin.jvm.internal.Intrinsics->areEqual ; android.net.Uri->getHost ; java.lang.String->hashCode ; java.lang.String->equals ; java.lang.StringBuilder-><init> ; java.lang.StringBuilder->append ; java.lang.StringBuilder->toString ; Eh.b->h
- `onActivityResult(I, I, android.content.Intent) -> V` regs=4 code_units=9
  calls: l2.q->onActivityResult ; Ne.a->b
- `onCreate(android.os.Bundle) -> V` regs=29 code_units=839
  calls: l2.q->onCreate ; java.util.concurrent.locks.ReentrantReadWriteLock->readLock ; java.util.concurrent.locks.ReentrantReadWriteLock->getWriteHoldCount ; java.util.concurrent.locks.ReentrantReadWriteLock->getReadHoldCount ; java.util.concurrent.locks.ReentrantReadWriteLock$ReadLock->unlock ; java.util.concurrent.locks.ReentrantReadWriteLock->writeLock ; java.util.concurrent.locks.ReentrantReadWriteLock$WriteLock->lock ; java.util.LinkedList->clear ; java.util.concurrent.locks.ReentrantReadWriteLock$ReadLock->lock
- `onNewIntent(android.content.Intent) -> V` regs=3 code_units=13
  calls: d.o->onNewIntent ; ru.zona.app.android.MainActivity->q ; ru.zona.app.android.MainActivity->p
- `onRequestPermissionsResult(I, [Ljava.lang.String, [I) -> V` regs=4 code_units=9
  calls: l2.q->onRequestPermissionsResult ; Ne.a->b
- `p(android.content.Intent) -> V` regs=15 code_units=413
  strings: ru.zona.app.OPEN_DOWNLOADS | https://az1.zona.pub/v1/auth | app521295504-login.tg.dev | trying to handle LoginResponse | onSuccess | onSuccess(Lorg/telegram/login/LoginData;)V | onError | onError(Lorg/telegram/login/LoginError;)V | android.intent.action.VIEW | android.intent.action.SEARCH
  calls: android.content.Intent->getBooleanExtra ; ga.u0->getValue ; Kd.f-><init> ; ga.u0->d ; 9.Q->a ; 9.I->b ; android.content.Intent->getData ; android.net.Uri->getHost ; kotlin.jvm.internal.Intrinsics->areEqual ; java.lang.Object->getClass ; Eh.b->d ; kotlin.jvm.internal.FunctionReferenceImpl-><init> ; org.telegram.login.TelegramLogin->handleLoginResponse ; android.net.Uri->getPath ; kotlin.Lazy->getValue ; android.net.Uri->toString ; oh.f->a ; java.lang.Throwable->printStackTrace ; kotlin.text.StringsKt->isBlank ; vd.p->invoke ; Kd.c-><init> ; da.h->c ; android.content.Intent->getAction ; android.net.Uri->getPathSegments ; kotlin.collections.CollectionsKt->firstOrNull ; java.lang.Iterable->iterator ; java.util.Iterator->hasNext ; java.util.Iterator->next ; android.net.Uri->getLastPathSegment ; Oh.c-><init> ; Kd.d->a
### ru.zona.app.services.download.StreamDownloadWorker$a
- `a(J) -> Ljava/lang/String;` regs=3 code_units=7
  strings: dl-
  calls: e0.t->a
### ru.zona.app.services.download.StreamDownloadWorker$b
- `<init>(ru.zona.app.services.download.StreamDownloadWorker, kotlin.coroutines.jvm.internal.ContinuationImpl) -> V` regs=3 code_units=6
  calls: kotlin.coroutines.jvm.internal.ContinuationImpl-><init>
- `invokeSuspend(java.lang.Object) -> Ljava/lang/Object;` regs=3 code_units=16
  calls: ru.zona.app.services.download.StreamDownloadWorker->c
### ru.zona.app.services.download.StreamDownloadWorker$c
- `<init>(ng.g, ru.zona.app.services.download.StreamDownloadWorker, J, ng.g, ng.Y, ng.H, kotlin.coroutines.Continuation) -> V` regs=9 code_units=17
  calls: kotlin.coroutines.jvm.internal.SuspendLambda-><init>
- `create(java.lang.Object, kotlin.coroutines.Continuation) -> Lkotlin/coroutines/Continuation;` regs=12 code_units=19
  calls: ru.zona.app.services.download.StreamDownloadWorker$c-><init>
- `invoke(java.lang.Object, java.lang.Object) -> Ljava/lang/Object;` regs=3 code_units=17
  calls: ru.zona.app.services.download.StreamDownloadWorker$c->create ; ru.zona.app.services.download.StreamDownloadWorker$c->invokeSuspend
- `invokeSuspend(java.lang.Object) -> Ljava/lang/Object;` regs=14 code_units=150
  strings: call to 'resume' before 'invoke' with coroutine | . | .part
  calls: kotlin.coroutines.intrinsics.IntrinsicsKt->getCOROUTINE_SUSPENDED ; kotlin.ResultKt->throwOnFailure ; java.lang.IllegalStateException-><init> ; ng.v->a ; java.lang.Enum->ordinal ; a6.e->b ; ru.zona.app.services.download.StreamDownloadWorker->d ; java.io.File->getParentFile ; java.io.File->getName ; android.support.v4.media.a->a ; java.io.File-><init> ; ru.zona.app.services.download.StreamDownloadWorker->f ; kotlin.NoWhenBranchMatchedException-><init> ; ru.zona.app.services.download.StreamDownloadWorker->e
### ru.zona.app.services.download.StreamDownloadWorker
- `<clinit>() -> V` regs=2 code_units=17
  calls: kotlin.jvm.internal.Reflection->getOrCreateKotlinClass ; kotlin.reflect.KClass->getSimpleName ; java.lang.Object-><init>
- `<init>(android.content.Context, androidx.work.WorkerParameters) -> V` regs=5 code_units=42
  calls: androidx.work.CoroutineWorker-><init> ; android.content.Context->getApplicationContext ; java.util.concurrent.atomic.AtomicInteger-><init> ; java.util.concurrent.atomic.AtomicLong-><init> ; java.util.concurrent.atomic.AtomicReference-><init>
- `d(ru.zona.app.services.download.StreamDownloadWorker, java.io.File) -> V` regs=2 code_units=19
  calls: java.io.File->exists ; java.io.File->delete ; java.io.File->getAbsolutePath ; java.lang.Object->getClass
- `e(ru.zona.app.services.download.StreamDownloadWorker, J, ng.g, ng.g, ng.Y, ng.H, kotlin.coroutines.jvm.internal.ContinuationImpl) -> Ljava/lang/Object;` regs=29 code_units=424
  strings: call to 'resume' before 'invoke' with coroutine
  calls: ng.r0-><init> ; kotlin.coroutines.intrinsics.IntrinsicsKt->getCOROUTINE_SUSPENDED ; kotlin.ResultKt->throwOnFailure ; java.lang.IllegalStateException-><init> ; a6.e->b ; java.io.File->isFile ; kotlin.coroutines.jvm.internal.SpillingKt->nullOutSpilledVariable ; ru.zona.app.services.download.StreamDownloadWorker->j ; android.net.Uri->fromFile ; android.net.Uri->toString ; ng.H->b ; s9.i-><init> ; java.lang.Object-><init> ; s9.i->a ; java.util.Map->isEmpty ; io.ktor.utils.io.i-><init> ; v9.n->a ; s9.b-><init> ; ng.t0-><init> ; da.h->f ; kotlin.io.CloseableKt->closeFinally
- `f(ru.zona.app.services.download.StreamDownloadWorker, J, ng.g, ng.Y, ng.H, kotlin.coroutines.jvm.internal.ContinuationImpl) -> Ljava/lang/Object;` regs=27 code_units=327
  strings: call to 'resume' before 'invoke' with coroutine | zona-transformer-
  calls: ng.u0-><init> ; kotlin.coroutines.intrinsics.IntrinsicsKt->getCOROUTINE_SUSPENDED ; kotlin.ResultKt->throwOnFailure ; java.lang.IllegalStateException-><init> ; ru.zona.app.services.download.StreamDownloadWorker->j ; android.net.Uri->fromFile ; android.net.Uri->toString ; ng.H->b ; e0.t->a ; android.os.HandlerThread-><init> ; java.lang.Thread->start ; android.os.HandlerThread->getLooper ; android.os.Handler-><init> ; T3.Z-><init> ; ng.A0-><init> ; ng.y0-><init> ; kotlin.coroutines.jvm.internal.SpillingKt->nullOutSpilledVariable ; da.h->f
- `g(ru.zona.app.services.download.StreamDownloadWorker, J, ng.Y, ng.H, kotlin.coroutines.jvm.internal.ContinuationImpl) -> Ljava/lang/Object;` regs=32 code_units=581
  strings: call to 'resume' before 'invoke' with coroutine | 
  calls: ng.D0-><init> ; kotlin.coroutines.intrinsics.IntrinsicsKt->getCOROUTINE_SUSPENDED ; kotlin.ResultKt->throwOnFailure ; java.lang.IllegalStateException-><init> ; java.util.concurrent.atomic.AtomicInteger->get ; java.util.concurrent.atomic.AtomicLong->get ; ng.z-><init> ; kotlin.jvm.internal.Intrinsics->areEqual ; kotlin.coroutines.jvm.internal.SpillingKt->nullOutSpilledVariable ; ng.H->f ; ng.Y->a ; ru.zona.app.services.download.StreamDownloadWorker->h ; N4.C->a ; A1.f->a ; kotlin.Result->constructor-impl ; kotlin.ResultKt->createFailure ; da.Y->b
- `k(ru.zona.app.services.download.StreamDownloadWorker, ic.c, ng.g, I, J, ic.e, java.lang.Boolean, java.lang.String, I) -> V` regs=20 code_units=79
  calls: kotlin.Lazy->getValue ; ud.a->b ; ic.o->b ; j$.util.Objects->toString ; java.lang.Object->getClass
- `c(kotlin.coroutines.Continuation) -> Ljava/lang/Object;` regs=27 code_units=1892
  strings: Download complete id: | call to 'resume' before 'invoke' with coroutine | download_id | No IDownloadDao in DownloadProcessDeps; cannot run work id: | No download record id: |  (removed?) — nothing to do | notification | zona_download | Загрузки | download_resumed |  ->  | invalid error code |  [ |  <-  | :  |  | last net:  | \s+ |   | No auto-retry id: |  — left FAILED for user decision | Download cancelled id:
  calls: ru.zona.app.services.download.StreamDownloadWorker$b-><init> ; kotlin.coroutines.intrinsics.IntrinsicsKt->getCOROUTINE_SUSPENDED ; java.lang.IllegalStateException-><init> ; kotlin.ResultKt->throwOnFailure ; java.lang.Long->valueOf ; java.util.HashMap->get ; java.lang.Number->longValue ; e0.t->a ; Eh.b->c ; androidx.work.d$a$a-><init> ; xd.i->d ; Q0.s->a ; Eh.b->d ; androidx.work.d$a$c-><init> ; android.content.Context->getSystemService ; android.app.NotificationManager->getNotificationChannel ; android.app.NotificationChannel-><init> ; android.app.NotificationManager->createNotificationChannel ; java.lang.System->currentTimeMillis ; ru.zona.app.services.download.StreamDownloadWorker->i ; java.lang.Boolean->booleanValue ; ru.zona.app.services.download.StreamDownloadWorker->k ; ng.E->c ; java.util.concurrent.atomic.AtomicInteger->set ; kotlin.coroutines.jvm.internal.SpillingKt->nullOutSpilledVariable ; ng.Y->a ; java.util.concurrent.atomic.AtomicInteger->get ; ru.zona.app.services.download.StreamDownloadWorker->h ; N4.C->a ; A1.f->a ; ng.H->i ; ru.zona.app.services.download.StreamDownloadWorker$c-><init> ; da.h->f ; android.net.Uri->fromFile ; android.net.Uri->toString ; ng.H->b ; ja
- `h(I, J, java.lang.String) -> LD4/k;` regs=9 code_units=121
  strings: zona_download | Загрузка видео | % | Загрузка…
  calls: I1.q-><init> ; kotlin.text.StringsKt->isBlank ; I1.q->b ; y2.i->a ; I1.q->c ; vd.j->invoke ; I1.q->a ; D4.k-><init>
- `i(J, ng.g, ng.H, kotlin.coroutines.jvm.internal.ContinuationImpl) -> Ljava/lang/Object;` regs=26 code_units=259
  strings: Re-resolve returned null id: | Re-resolved stream URL id: | call to 'resume' before 'invoke' with coroutine |  before start |  — keep stored streamInfo
  calls: ng.B0-><init> ; kotlin.coroutines.intrinsics.IntrinsicsKt->getCOROUTINE_SUSPENDED ; kotlin.ResultKt->throwOnFailure ; java.lang.IllegalStateException-><init> ; ng.C0-><init> ; kotlin.coroutines.jvm.internal.SpillingKt->nullOutSpilledVariable ; da.h->f ; ng.H->h ; java.lang.StringBuilder-><init> ; java.lang.StringBuilder->append ; java.lang.StringBuilder->toString ; Eh.b->d ; ng.g->a ; java.lang.Object->getClass
- `j(ng.g, kotlin.coroutines.jvm.internal.ContinuationImpl) -> Ljava/lang/Object;` regs=9 code_units=136
  strings: call to 'resume' before 'invoke' with coroutine
  calls: ng.E0-><init> ; kotlin.coroutines.intrinsics.IntrinsicsKt->getCOROUTINE_SUSPENDED ; kotlin.ResultKt->throwOnFailure ; java.lang.IllegalStateException-><init> ; Dd.d->d ; ng.E->b ; ng.k0-><init> ; java.lang.Integer->valueOf ; ng.k0->invoke ; java.io.File->getParentFile ; java.io.File->mkdirs ; java.io.File->createNewFile
