# Stage 5 — recovered wire-model schema

## Evidence method

Field names below are read from the `<clinit>` method of each model's generated Kotlin serialization class (`<Model>$$serializer`). Types are cross-checked against the model's JVM getter signatures. JVM signatures do not reliably disclose Kotlin nullability. These findings are stronger than plain string-pool matches, but they are not a reconstruction of API routes or a complete decompilation.

## Confirmed serialized keys

### `mobi.zona.data.model.VideoSource`

| JSON key | JVM getter type |
|---|---|
| `id` | `String` |
| `episode_key` | `String` |
| `download_link_key` | `String` |
| `kinopoisk_id` | `long` |
| `video_source_type_id` | `int` |
| `video_content_type_id` | `int` |
| `info` | `String` |

### `mobi.zona.data.model.StreamInfo`

| JSON key | JVM getter type |
|---|---|
| `url` | `String` |
| `translation` | `String` |
| `language` | `String` |
| `quality` | `String` |
| `subtitleList` | `List` |
| `userAgent` | `String` |
| `headers` | `Map` |
| `unavailableQuality` | `boolean` |
| `isTrailer` | `boolean` |
| `videoSourceTypeId` | `int` |
| `videoContentTypeId` | `int` |
| `codec` | `String` |

### `mobi.zona.data.model.Subtitle`

| JSON key | JVM getter type |
|---|---|
| `name` | `String` |
| `url` | `String` |
| `language` | `String` |
| `codec` | `String` |

### `mobi.zona.data.model.Episode`

| JSON key | JVM getter type |
|---|---|
| `title` | `String` |
| `episode_key` | `String` |
| `mobi_link_id` | `long` |
| `season` | `int` |
| `episode` | `int` |
| `release_date` | `String` |
| `isWatched` | `boolean` |
| `isEnable` | `boolean` |

### Response envelopes

- `VideoSourcesResponse`: `total: long`, `data: List`, `collation: String`.
- `MoviesResponse`: `total: long`, `data: List`, `collation: String`.
- `Collection`: `id: long`, `title: String`, `data: List`.
- `RelationsResponse`: `relations: List`, `recommendations: List`.

### `mobi.zona.data.model.Movie`

The serializer metadata confirms these keys (in serialized order):

`id`, `name`, `coverUrl`, `year`, `description`, `quality`, `trailerSourceTypes`, `movieSourceTypes`, `genres`, `countries`, `zonaRating`, `imdbRating`, `ksRating`, `director`, `directors`, `scenario`, `strid`, `writers`, `releaseDateInt`, `releaseDateRus`, `actors`, `originalName`, `duration`, `rels`, `serial`, `isLiked`, `isWatched`, `isHasEpisodeKeys`, `updatedAt`, `short`, `posterTemplate`, `vast`, `adsModel`.

The current `ZonaWireMovieSummary` intentionally models only a subset needed for a future catalogue projection. It must not be mistaken for the complete `Movie` wire model.

## Additional method-reference finding

A second scan of DEX invoke instructions found no direct call sites outside generated/model code for `VideoSource.getInfo`, `StreamInfo.getUrl`, `StreamInfo.getHeaders`, or `StreamInfo.getSubtitleList`. This leaves the conversion path between the `VideoSource.info` string and a playable `StreamInfo` unresolved. The result is recorded in `STAGE5_DEX_FINDINGS.md` and the scan is reproducible with `extract_stage5.py`.

## Project changes in Stage 5

- Added `ZonaWireModels.kt` with serializable DTOs for episodes, video sources, stream information, subtitles, and response envelopes.
- Added `ZonaWireJson.kt` with JSON decoders configured to ignore unknown keys and coerce invalid optional values.
- Added the Kotlin serialization Gradle plugin and `kotlinx-serialization-json` dependency.
- Added `extract_stage5.py` so this targeted extraction can be repeated against a supplied APK.
- Added a mapping from the recovered `StreamInfo` fields to the LUMI playback boundary. Only HTTP(S) URLs are accepted, and subtitle URLs are filtered the same way.

## Important correction to earlier notes

The current DEX class-definition scan does **not** find declared classes named `MovieStreamService`, `VideoSourcesServiceWithCache`, or `EpisodeServiceWithCache` in this APK. Those names appeared in earlier progress notes but are not substantiated by the repeatable scan and should be treated as unverified. The APK does contain `VideoSource`, `StreamInfo`, `VideoSourcesResponse`, and `Episode` data models.

The scan confirms `/getUpdate`, `app_type`, and `versionCode` in `UpdateZonaApiImpl.getUpdate`. It also confirms an auth URL and Telegram Login callback strings in `MainActivity`. It does not yet establish the live catalogue or stream-source endpoint contract.

## Validation status

The extractor was run against the provided `zona5.apk` and generated `STAGE5_DEX_FINDINGS.md`. The source DTOs and Gradle configuration were added to the project, but a full Android/Gradle compile was not possible in this environment because Android SDK and Gradle are absent. The new Kotlin serialization source has therefore **not** been claimed as compiled or runtime-tested.
