# Stage 5 targeted DEX extraction

This report extracts serialization field keys and method-level string constants from the supplied APK.
It is not Java/Kotlin source decompilation and does not establish server availability.

## DEX inventory
DEX files: 4 (`classes.dex, classes2.dex, classes3.dex, classes4.dex`).
- classes.dex: 15025 class definitions, 65524 method IDs, 47925 strings.
- classes2.dex: 580 class definitions, 5499 method IDs, 2287 strings.
- classes3.dex: 11790 class definitions, 65449 method IDs, 57580 strings.
- classes4.dex: 12944 class definitions, 54100 method IDs, 45871 strings.

### `mobi.zona.data.UpdateZonaApiImpl.getUpdate` string constants

- `call to 'resume' before 'invoke' with coroutine`
- `/getUpdate`
- `app_type`
- `versionCode`

### `mobi.zona.data.model.Episode` serialized keys

`title`, `episode_key`, `mobi_link_id`, `season`, `episode`, `release_date`, `isWatched`, `isEnable`


### `mobi.zona.data.model.Movie` serialized keys

`id`, `name`, `coverUrl`, `year`, `description`, `quality`, `trailerSourceTypes`, `movieSourceTypes`, `genres`, `countries`, `zonaRating`, `imdbRating`, `ksRating`, `director`, `directors`, `scenario`, `strid`, `writers`, `releaseDateInt`, `releaseDateRus`, `actors`, `originalName`, `duration`, `rels`, `serial`, `isLiked`, `isWatched`, `isHasEpisodeKeys`, `updatedAt`, `short`, `posterTemplate`, `vast`, `adsModel`


### `mobi.zona.data.model.StreamInfo` serialized keys

`url`, `translation`, `language`, `quality`, `subtitleList`, `userAgent`, `headers`, `unavailableQuality`, `isTrailer`, `videoSourceTypeId`, `videoContentTypeId`, `codec`


### `mobi.zona.data.model.Subtitle` serialized keys

`name`, `url`, `language`, `codec`


### `mobi.zona.data.model.VideoSource` serialized keys

`id`, `episode_key`, `download_link_key`, `kinopoisk_id`, `video_source_type_id`, `video_content_type_id`, `info`


### `mobi.zona.data.model.response.Collection` serialized keys

`id`, `title`, `data`


### `mobi.zona.data.model.response.MoviesResponse` serialized keys

`total`, `data`, `collation`


### `mobi.zona.data.model.response.RelationsResponse` serialized keys

`relations`, `recommendations`


### `mobi.zona.data.model.response.VideoSourcesResponse` serialized keys

`total`, `data`, `collation`


### `ru.zona.app.android.MainActivity.q` string constants

- `mobi.zona`
- `rustore`
- `Unknown app scheme link: `

### `ru.zona.app.android.MainActivity.p` string constants

- `ru.zona.app.OPEN_DOWNLOADS`
- `https://az1.zona.pub/v1/auth`
- `app521295504-login.tg.dev`
- `trying to handle LoginResponse`
- `onSuccess`
- `onSuccess(Lorg/telegram/login/LoginData;)V`
- `onError`
- `onError(Lorg/telegram/login/LoginError;)V`
- `android.intent.action.VIEW`
- `android.intent.action.SEARCH`

### `ru.zona.app.services.download.StreamDownloadWorker.e` string constants

- `call to 'resume' before 'invoke' with coroutine`

### `ru.zona.app.services.download.StreamDownloadWorker.f` string constants

- `call to 'resume' before 'invoke' with coroutine`
- `zona-transformer-`

### `ru.zona.app.services.download.StreamDownloadWorker.g` string constants

- `call to 'resume' before 'invoke' with coroutine`
- ``

### `ru.zona.app.services.download.StreamDownloadWorker.j` string constants

- `call to 'resume' before 'invoke' with coroutine`

## Direct getter call-site scan

No direct DEX invoke call sites were found for `VideoSource.getInfo`, `StreamInfo.getUrl`, `StreamInfo.getHeaders`, or `StreamInfo.getSubtitleList` outside generated/model code.
This does not rule out reflection, native code, or use through another serialized path; it means the conversion path from `VideoSource.info` to `StreamInfo` is not yet established by direct method references.

## Interpretation limits

- `UpdateZonaApiImpl.getUpdate` exposes `/getUpdate`, `app_type`, and `versionCode` in method constants.
- `MainActivity.p` exposes the `OPEN_DOWNLOADS` action, an auth URL, and Telegram Login callback names.
- `StreamDownloadWorker` has a `zona-transformer-` constant and calls obfuscated helpers; this alone does not prove how stream URLs are fetched.
- The app namespace scan did not find declared classes named `MovieStreamService`, `VideoSourcesServiceWithCache`, or `EpisodeServiceWithCache`. Prior notes naming these as classes should be treated as unverified.
- Endpoint fragments do not reveal HTTP method, full base URL, required headers, authentication, or server availability.
