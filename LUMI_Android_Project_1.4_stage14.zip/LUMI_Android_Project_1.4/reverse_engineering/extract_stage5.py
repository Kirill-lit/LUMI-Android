#!/usr/bin/env python3
"""Stage 5 targeted DEX metadata extractor; does not decompile source code."""
import argparse, importlib.util, os, re, struct, zipfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARSER = os.path.join(HERE, "tools_extract_dex_methods.py")
spec = importlib.util.spec_from_file_location("dexextract", PARSER)
dexextract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dexextract)

TARGET_MODELS = [
    "mobi.zona.data.model.Episode",
    "mobi.zona.data.model.Movie",
    "mobi.zona.data.model.VideoSource",
    "mobi.zona.data.model.StreamInfo",
    "mobi.zona.data.model.Subtitle",
    "mobi.zona.data.model.response.VideoSourcesResponse",
    "mobi.zona.data.model.response.MoviesResponse",
    "mobi.zona.data.model.response.Collection",
    "mobi.zona.data.model.response.RelationsResponse",
]
TARGET_METHOD_CLASSES = {
    "mobi.zona.data.UpdateZonaApiImpl",
    "ru.zona.app.android.MainActivity",
    "ru.zona.app.services.download.StreamDownloadWorker",
}

def read_strings_from_method(b, code_off, strings):
    if not code_off:
        return []
    regs, ins, outs, tries, dbg, size = struct.unpack_from("<HHHHII", b, code_off)
    insns = list(struct.unpack_from("<" + "H" * size, b, code_off + 16))
    found, i = [], 0
    W = dexextract.W
    while i < size:
        w = insns[i]
        op = w & 255
        width = W.get(op, 1)
        if op == 0 and w in (0x0100, 0x0200, 0x0300):
            if w == 0x0100: width = 4 + insns[i+1] * 2
            elif w == 0x0200: width = 2 + insns[i+1] * 4
            else: width = 4 + ((insns[i+1] + 1) // 2) * 2
        if op == 0x1a and i + 1 < size:
            found.append(strings[insns[i+1]])
        elif op == 0x1b and i + 2 < size:
            ix = insns[i+1] | (insns[i+2] << 16)
            if ix < len(strings): found.append(strings[ix])
        i += max(width, 1)
    return list(dict.fromkeys(found))

def main(apk, out_path):
    out = ["# Stage 5 targeted DEX extraction", "",
           "This report extracts serialization field keys and method-level string constants from the supplied APK.",
           "It is not Java/Kotlin source decompilation and does not establish server availability.", ""]
    with zipfile.ZipFile(apk) as z:
        dexes = [n for n in z.namelist() if n.endswith(".dex") and "/" not in n]
        out.append("## DEX inventory")
        out.append(f"DEX files: {len(dexes)} (`{', '.join(dexes)}`).")
        for dn in dexes:
            b = z.read(dn)
            strings, methods, classes, _ = dexextract.parse(b)
            out.append(f"- {dn}: {len(classes)} class definitions, {len(methods)} method IDs, {len(strings)} strings.")
            mref = {i: m for i, m in enumerate(methods)}
            sref = {i: s for i, s in enumerate(strings)}
            for cname, members in classes:
                if cname in TARGET_MODELS:
                    ser_name = cname + "$$serializer"
                    ser = next((x for x in classes if x[0] == ser_name), None)
                    if not ser:
                        continue
                    clinit = next((m for m in ser[1] if m[0][1] == "<clinit>" and m[1]), None)
                    if not clinit:
                        continue
                    keys = read_strings_from_method(b, clinit[1], strings)
                    # Keep serializer name plus model keys, excluding the leading class-name string.
                    keys = [k for k in keys if k != cname]
                    out.extend(["", f"### `{cname}` serialized keys", "", ", ".join(f"`{k}`" for k in keys), ""])
                if cname in TARGET_METHOD_CLASSES:
                    for method, code, access in members:
                        name = method[1]
                        if not code:
                            continue
                        interesting = (cname == "ru.zona.app.android.MainActivity" and name in {"p", "q", "onCreate"}) or \
                                      (cname == "mobi.zona.data.UpdateZonaApiImpl" and name == "getUpdate") or \
                                      (cname == "ru.zona.app.services.download.StreamDownloadWorker" and name in {"e", "f", "g", "j"})
                        if not interesting:
                            continue
                        strings_found = read_strings_from_method(b, code, strings)
                        if strings_found:
                            out.extend(["", f"### `{cname}.{name}` string constants", ""])
                            out.extend(f"- `{x}`" for x in strings_found)
    # Scan invoke instructions for direct references to key model getters.
    call_sites = []
    watched = {
        ("mobi.zona.data.model.VideoSource", "getInfo"),
        ("mobi.zona.data.model.StreamInfo", "getUrl"),
        ("mobi.zona.data.model.StreamInfo", "getHeaders"),
        ("mobi.zona.data.model.StreamInfo", "getSubtitleList"),
    }
    with zipfile.ZipFile(apk) as z:
        for dn in [n for n in z.namelist() if n.endswith(".dex") and "/" not in n]:
            b = z.read(dn)
            strings, methods, classes, _ = dexextract.parse(b)
            method_refs = {i: m for i, m in enumerate(methods)}
            for caller, members in classes:
                for caller_method, code, access in members:
                    if not code:
                        continue
                    regs, ins, outs, tries, dbg, size = struct.unpack_from("<HHHHII", b, code)
                    insns = list(struct.unpack_from("<" + "H" * size, b, code + 16))
                    i = 0
                    while i < size:
                        word = insns[i]
                        op = word & 255
                        width = dexextract.W.get(op, 1)
                        if op == 0 and word in (0x0100, 0x0200, 0x0300):
                            if word == 0x0100: width = 4 + insns[i+1] * 2
                            elif word == 0x0200: width = 2 + insns[i+1] * 4
                            else: width = 4 + ((insns[i+1] + 1) // 2) * 2
                        if op in list(range(0x6e, 0x73)) + list(range(0x74, 0x79)) and i + 1 < size:
                            target = method_refs.get(insns[i+1])
                            if target and (target[0], target[1]) in watched:
                                call_sites.append((dn, caller, caller_method[1], target[0], target[1]))
                        i += max(width, 1)
    out.extend(["", "## Direct getter call-site scan", ""])
    external_sites = [x for x in call_sites if not x[1].startswith("mobi.zona.data.model.")]
    if external_sites:
        out.extend(f"- `{caller}.{caller_method}` calls `{owner}.{method}` ({dex})"
                   for dex, caller, caller_method, owner, method in external_sites)
    else:
        out.append("No direct DEX invoke call sites were found for `VideoSource.getInfo`, `StreamInfo.getUrl`, `StreamInfo.getHeaders`, or `StreamInfo.getSubtitleList` outside generated/model code.")
        out.append("This does not rule out reflection, native code, or use through another serialized path; it means the conversion path from `VideoSource.info` to `StreamInfo` is not yet established by direct method references.")

    out.extend(["", "## Interpretation limits", "",
        "- `UpdateZonaApiImpl.getUpdate` exposes `/getUpdate`, `app_type`, and `versionCode` in method constants.",
        "- `MainActivity.p` exposes the `OPEN_DOWNLOADS` action, an auth URL, and Telegram Login callback names.",
        "- `StreamDownloadWorker` has a `zona-transformer-` constant and calls obfuscated helpers; this alone does not prove how stream URLs are fetched.",
        "- The app namespace scan did not find declared classes named `MovieStreamService`, `VideoSourcesServiceWithCache`, or `EpisodeServiceWithCache`. Prior notes naming these as classes should be treated as unverified.",
        "- Endpoint fragments do not reveal HTTP method, full base URL, required headers, authentication, or server availability."
    ])
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")
    print(f"Wrote {out_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("apk")
    parser.add_argument("--out", default="STAGE5_DEX_FINDINGS.md")
    args = parser.parse_args()
    main(args.apk, args.out)
