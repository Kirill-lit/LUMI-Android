## classes.dex
## classes2.dex
## classes3.dex
## classes4.dex
mobi.zona.data.model.Actor$$serializer: id, name, surname, avatarUrl
mobi.zona.data.model.Ads$$serializer: type, device, places, place, name_rus, genres, overview_rus, poster, backdrop, screenshots, download, tv, package, backdrop_tv, hide, url, check_install
mobi.zona.data.model.AppData$$serializer: settings, sorting, filters
mobi.zona.data.model.Channel$$serializer: id, name, links, adult, imageURL, country, genres, isChecked
mobi.zona.data.model.Country$$serializer: size, id, ids, name
mobi.zona.data.model.Episode$$serializer: title, episode_key, mobi_link_id, season, episode, release_date, isWatched, isEnable
mobi.zona.data.model.Feedback$$serializer: movie, serial, player
mobi.zona.data.model.FeedbackErrorItem$$serializer: type, name
mobi.zona.data.model.Filters$$serializer: country, genre, tvGenre
mobi.zona.data.model.Genre$$serializer: id, name, ord
mobi.zona.data.model.Links$$serializer: tg
mobi.zona.data.model.LinksItem$$serializer: app, web
mobi.zona.data.model.Movie$$serializer: id, name, coverUrl, year, description, quality, trailerSourceTypes, movieSourceTypes, genres, countries, zonaRating, imdbRating, ksRating, director, directors, scenario, strid, writers, releaseDateInt, releaseDateRus, actors, originalName, duration, rels, serial, isLiked, isWatched, isHasEpisodeKeys, updatedAt, short, posterTemplate, vast, adsModel
mobi.zona.data.model.Rel$$serializer: rmi, mi, r, p
mobi.zona.data.model.RequestBody$$serializer: limit, offset, sortBy, filter, movie_source_types
mobi.zona.data.model.SearchFilter$$serializer: genres, countries, yearFrom, yearTo, ratingFrom, ratingTo
mobi.zona.data.model.Settings$$serializer: volume, feedback, mytarget, mytarget.timeout, yak, mytarget.key, check.urls, holiday_url, logLevel, posters, noad_threshold, share, year, ads2, sync.server, analytic.url, payment.enabled, payment.loadOrderTimeOutMs, ve2, dc, loadAdTimeoutMs, links
mobi.zona.data.model.Share$$serializer: app, movie
mobi.zona.data.model.SortingItem$$serializer: name, id
mobi.zona.data.model.StreamInfo$$serializer: url, translation, language, quality, subtitleList, userAgent, headers, unavailableQuality, isTrailer, videoSourceTypeId, videoContentTypeId, codec
mobi.zona.data.model.Subtitle$$serializer: name, url, language, codec
mobi.zona.data.model.TvLink$$serializer: b, l, u
mobi.zona.data.model.Update$$serializer: apkUrl, apiHost, vastUrl, whatsNew, versionCode
mobi.zona.data.model.UpdateWhatsNew$$serializer: appVersion, releaseDate, messages, title, versionCode
mobi.zona.data.model.VideoSource$$serializer: id, episode_key, download_link_key, kinopoisk_id, video_source_type_id, video_content_type_id, info
mobi.zona.data.model.WhatsNewMessage$$serializer: text, title
mobi.zona.data.model.request.AnalyticRequest$$serializer: params
mobi.zona.data.model.request.FeedbackRequest$$serializer: category, type, movie_id, streamInfo, description, contact, episodeKey, androidId
mobi.zona.data.model.request.RelationsRequest$$serializer: id, rels, short
mobi.zona.data.model.request.UrlStatus$$serializer: url, status, error
mobi.zona.data.model.request.UrlStatusRequest$$serializer: id, deviceID, adUrl, adError, statuses
mobi.zona.data.model.response.ClientInfo$$serializer: ip
mobi.zona.data.model.response.Collection$$serializer: id, title, data
mobi.zona.data.model.response.MoviesResponse$$serializer: total, data, collation
mobi.zona.data.model.response.RecommendationsResponse$$serializer: recommendations, collections
mobi.zona.data.model.response.RelationsResponse$$serializer: relations, recommendations
mobi.zona.data.model.response.VastResponse$$serializer: vast
mobi.zona.data.model.response.VideoSourcesResponse$$serializer: total, data, collation