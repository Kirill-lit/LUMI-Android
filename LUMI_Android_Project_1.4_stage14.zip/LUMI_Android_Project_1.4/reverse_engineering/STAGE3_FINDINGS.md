# LUMI / Zona reverse engineering — Stage 3

## New code-level evidence extracted from DEX method bodies

This stage adds a lightweight DEX code-item scanner. It reads class data and method code items, then records string constants and method references from selected concrete classes. It is not a full decompiler; register flow, branches, Kotlin coroutine state machines, and obfuscated calls are not reconstructed as source.

### Findings

- `mobi.zona.data.UpdateZonaApiImpl.getUpdate(...)` contains the route fragment `/getUpdate` and parameter names `app_type` and `versionCode`. The method calls an obfuscated HTTP/client stack and a serializer for the `Update` model. This confirms one concrete API request contract fragment, but not a complete base URL or all headers.
- `ru.zona.app.android.MainActivity.q(Intent)` checks URI scheme/host and includes `mobi.zona`, `rustore`, and an unknown-app-scheme error. `MainActivity.p(Intent)` handles intent routes including `ru.zona.app.OPEN_DOWNLOADS`, the authentication base `https://az1.zona.pub/v1/auth`, and Telegram login response handling. This shows that deep-link and auth behavior is part of the original app and should not be recreated from string guesses alone.
- `ru.zona.app.services.download.StreamDownloadWorker` contains concrete download lifecycle strings such as `Download complete id`, `download_id`, `Download cancelled id`, and `No download record id`. Its helper methods include stream re-resolution strings `Re-resolve returned null id` and `Re-resolved stream URL id`, plus `zona-transformer-` and temporary `.part` files. The download flow is more than a direct URL fetch; it depends on persisted download records and stream re-resolution.
- The actual DEX class definitions did **not** include concrete classes named `MovieStreamService`, `VideoSourcesServiceWithCache`, or `EpisodeServiceWithCache`, despite those names appearing in Kotlin/source metadata strings. They may be metadata/source names, stripped or transformed classes, or otherwise not directly addressable as class definitions in this APK. Therefore no implementation claim is made about their method bodies.

## LUMI implementation added in this stage

- Added UI-domain models for titles, stream info, subtitles, and playback history.
- Added a `CatalogRepository` boundary and an offline demo repository. The UI can play entries from the demo catalogue rather than only a single hard-coded button.
- Added a mapping boundary reflecting fields observed in Zona's `StreamInfo` and `Subtitle` models. It validates HTTP(S) URLs, maps HLS/DASH/MP4 MIME types, and preserves headers and User-Agent for playback. It does **not** parse Zona's network responses because their full contract has not been recovered.
- The player now accepts request headers and User-Agent, uses a configurable HTTP data-source factory, and infers common HLS/DASH/MP4 types.
- Playback position is periodically persisted every five seconds, saved on lifecycle transitions/disposal, and cleared when playback reaches the end. Playback history stores the last 20 items locally. Audio preference remains stored per series and is applied through Media3 track-selection parameters when matching audio tracks exist.

## Validation performed

- Compiled `CatalogModels.kt`, `CatalogRepository.kt`, and `ZonaModelMapping.kt` with the installed Kotlin compiler into a JAR successfully.
- Ran a small runtime check confirming HLS MIME mapping, preservation of a `Referer` header, and rejection of a `file://` URL. Result: PASS.
- Full Android build and APK installation remain unverified because this environment has no Android SDK, Gradle executable, JADX, or Apktool. The full UI/player source has not been compiled against Android dependencies here.

## Integration boundary

The demo repository is deliberately offline and safe. It does not call Zona endpoints. Connecting the real catalogue requires recovering the full API base selection, request headers/auth, serialization shape, and stream refresh rules. Those cannot be inferred safely from route strings alone.
