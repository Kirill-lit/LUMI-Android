#!/usr/bin/env python3
"""Inspect selected DEX methods with offsets and method references; emits evidence, not pseudocode."""
import importlib.util, struct, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APK = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/mnt/data/zona5.apk")
spec = importlib.util.spec_from_file_location("dexparser", ROOT / "tools_extract_dex_methods.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

with zipfile.ZipFile(APK) as z:
    dex_names = [n for n in z.namelist() if n.endswith(".dex") and "/" not in n]
    targets = []
    for dn in dex_names:
        strings, methods, classes, blob = mod.parse(z.read(dn))
        for owner, members in classes:
            for meth, code_off, access in members:
                if owner in {"zh.o", "rh.I", "Bd.u"} or (owner == "mobi.zona.data.model.VideoSource"):
                    if meth[1] in {"a", "invoke", "invokeSuspend", "getInfo", "getUrl", "getTranslation"}:
                        targets.append((dn, owner, meth, code_off, blob, methods))
    lines = []
    for dn, owner, meth, code_off, blob, methods in targets:
        lines.append(f"\n=== {dn}: {owner}.{meth[1]} proto={meth[2]} code_off={code_off} ===")
        if not code_off:
            lines.append("NO_CODE")
            continue
        regs, ins, outs, tries, dbg, size = struct.unpack_from("<HHHHII", blob, code_off)
        units = struct.unpack_from("<" + "H" * size, blob, code_off + 16)
        lines.append(f"registers={regs} ins={ins} outs={outs} insns={size}")
        i = 0
        while i < size:
            word = units[i]
            op = word & 0xff
            width = mod.W.get(op, 1)
            if op == 0 and word in (0x0100, 0x0200, 0x0300):
                if word == 0x0100: width = 4 + units[i+1] * 2
                elif word == 0x0200: width = 2 + units[i+1] * 4
                else: width = 4 + ((units[i+1] + 1) // 2) * 2
            detail = f"{i:04d}: opcode=0x{op:02x} word=0x{word:04x} width={width}"
            # 35c / 3rc method invoke opcodes
            if op in list(range(0x6e, 0x73)) + list(range(0x74, 0x79)) and i + 1 < size:
                mid = units[i+1]
                if 0 <= mid < len(methods):
                    m = methods[mid]
                    detail += f" method_ref={m[0]}.{m[1]} {m[2]}"
            # string const
            if op == 0x1a and i + 1 < size:
                sid = units[i+1]
                if sid < len(getattr(mod, "STRINGS", [])):
                    detail += f" string_id={sid}"
            lines.append(detail)
            i += max(1, width)
    print("\n".join(lines))
