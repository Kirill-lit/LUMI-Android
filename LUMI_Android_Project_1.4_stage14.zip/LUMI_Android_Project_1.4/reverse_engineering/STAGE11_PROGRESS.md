# LUMI 1.1 — Stage 11: fix source blockers and add reproducible Android build

## Concrete source fixes
- Replaced a literal newline inside a normal Kotlin string with the escaped `\\n` sequence.
- Removed a duplicated `@Composable` annotation above `SearchCatalogScreen`.
- Updated app version metadata to `versionCode 11` / `versionName 1.1.0`.
- Updated the player/network User-Agent labels to LUMI 1.1.
- Simplified the URL-builder unit test's expected encoded JSON string.

These were identified by inspecting the actual source files; the first two are real Kotlin source-level build blockers.

## Build route
Added `.github/workflows/android-build.yml`. On GitHub it provisions JDK 17, Android SDK 35 and Gradle 8.9, runs unit tests and `assembleDebug`, then uploads `app-debug.apk` as a downloadable workflow artifact. `BUILD_APK.md` documents the steps.

## Verification boundaries
This environment has Java but no `gradle`, `kotlinc`, Android SDK, `adb`, JADX or Apktool. Therefore I could not execute the Android compile locally, and I do not claim the APK has been built. The next real build result must come from the workflow run; its output will identify any remaining compile errors.

## API integration
No changes were made to bypass the unresolved `/getVideoSources` transform. The live Zona catalog remains unconnected.
