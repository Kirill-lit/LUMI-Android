# LUMI 0.6.0 — Android source project

This is a work-in-progress Android project based on the original user's design requirements and partial reverse-engineering of `zona5.apk`.

## Current contents

- Graphite Jetpack Compose UI prototype.
- Media3 playback foundation.
- Playback position and preferred audio-language persistence.
- Local demo catalog, search, favorites, and history.
- Partial JSON DTOs matching confirmed Zona wire-model keys.
- Recovered endpoint/request-contract registry.
- Safe URL builder for the confirmed `params=<URL-encoded serialized JSON>` request shape. It refuses the `/getVideoSources` route because the APK applies an additional transform that has not yet been recovered.
- Reverse-engineering reports and a DEX literal verification script.

## Important limitations

This is not yet a replacement for Zona. The live catalog and source retrieval are not connected. Server host selection, authentication, full response contracts, and the `/getVideoSources` parameter transform remain unresolved. No installable APK has been built or tested on a device.

## Build

Open the project root in Android Studio with a compatible Android SDK and Gradle setup. The current environment used to prepare these sources does not have Android SDK/Gradle available, so a full Android build has not been verified.

## Reverse-engineering artifacts

See `reverse_engineering/STAGE6_PROGRESS.md`, `STAGE6_ENDPOINT_CALLS.md`, and `STAGE6_ENDPOINT_CALL_DETAILS.md`. Re-run `python reverse_engineering/verify_stage6_contract.py /path/to/zona5.apk` to verify the documented route and host literals against the APK.


## Stage 7 additions

- `ZonaApiClient.kt`: opt-in transport for confirmed `params`-JSON routes; not yet wired to live UI.
- `reverse_engineering/STAGE7_PROGRESS.md`: findings about the `/getVideoSources` transform and verification limits.
- `reverse_engineering/verify_stage7_transform.py`: re-checks the actual APK for the transform call site.

Android build remains unverified because this environment lacks Android SDK and Gradle.


## Stage 8

See `reverse_engineering/STAGE8_PROGRESS.md`. The video-source transform remains intentionally disabled until its exact byte-level algorithm is proven.


## Stage 9

See `reverse_engineering/STAGE9_PROGRESS.md` and `STAGE9_TARGET_DISASSEMBLY.txt` for a more complete instruction listing of the video-source parameter transform and its call sites.


## Stage 10 / version 1.0

Focused transform trace: `reverse_engineering/STAGE10_TRANSFORM_TRACE.txt`. See `STAGE10_PROGRESS.md` for confirmed findings and remaining blockers.


## LUMI 1.1 — build readiness

See `BUILD_APK.md` for the reproducible GitHub Actions build route and `reverse_engineering/STAGE11_PROGRESS.md` for the source fixes. The debug APK has not yet been compiled in this environment.


## LUMI 1.2: live catalogue

LUMI now uses Internet Archive's public read-only APIs to show real media records with Creative Commons license URLs and resolves a media file before opening ExoPlayer. See `reverse_engineering/STAGE12_PROGRESS.md`. This is not a Zona API integration; the original Zona video-source transformation is still unresolved.


Run `python reverse_engineering/preflight_check.py` for the available static project checks. This is not a substitute for the GitHub Actions Gradle build.


See `HARD_BUILD_AUDIT.md` for the static hard-check results and remaining verification limits.
