# Build LUMI 1.2 APK

The project contains `.github/workflows/android-build.yml`, which provisions JDK 17, Android SDK 35 and Gradle 8.9, runs a clean unit-test build, assembles the debug APK and uploads it as `LUMI-1.2-debug-apk`.

## Run
1. Extract this ZIP.
2. Upload the contents (including `.github`) to a GitHub repository.
3. Open **Actions** → **Build LUMI Android APK** → **Run workflow**.
4. Wait for `clean testDebugUnitTest assembleDebug` to succeed.
5. Download artifact `LUMI-1.2-debug-apk`; install `app-debug.apk` on the device.

No APK is included in this ZIP because the current execution environment has no Android SDK/Gradle and cannot download them. Do not treat the build as verified until the workflow is green.

## Catalogue and playback
The app uses Internet Archive public search/metadata endpoints to load real Creative Commons-licensed catalogue records and find media files for ExoPlayer. Network access is required. Some records may not have compatible files. The original Zona catalogue/API is not connected.


The workflow also uploads `LUMI-1.2-build-reports` even when compilation fails. If it fails, download that artifact and share the Gradle error log so the exact remaining compile errors can be corrected.


See `HARD_BUILD_AUDIT.md` for what has been checked locally and what still requires a real Gradle build.
